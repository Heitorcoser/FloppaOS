#!/bin/bash
# floppa-otimizer.sh - extra "Floppa Otimizer": ajuda a otimizar o MeuOS conforme a memoria,
# o processador, o video e o disco do PC (ou da maquina virtual).
command -v zenity >/dev/null || { echo "zenity ausente"; exit 1; }

DIR=$(dirname "$(readlink -f "$0")")
AP="$DIR/floppa-otimizer-aplicar.sh"
TITULO="Floppa Otimizer"

[ -f "$AP" ] || { zenity --error --no-markup --title="$TITULO" \
    --text="Faltou o arquivo floppa-otimizer-aplicar.sh. Remova e instale o extra de novo." 2>/dev/null; exit 1; }

val() { echo "$INFO" | sed -n "s/^$1=//p" | head -n1; }
ram_livre() { free -m | awk '/^Mem:/ {print $7}'; }

# roda o motor como root: direto se ja for root, sem senha se o sudo permitir, senao pede a senha
como_root() {
    local senha
    if [ "$EUID" -eq 0 ]; then
        bash "$AP" "$@" 2>&1
        return
    fi
    if sudo -n true >/dev/null 2>&1; then
        sudo -n bash "$AP" "$@" 2>&1
        return
    fi
    senha=$(zenity --password --title="$TITULO" 2>/dev/null) || return 1
    printf '%s\n' "$senha" | sudo -S -p '' bash "$AP" "$@" 2>&1
}

resumo() {
    echo "Memoria: $(val RAM_MB) MB   |   Processador: $(val CPUS) nucleo(s)"
    echo "CPU: $(val CPU)"
    echo "Video: $(val GPU)"
    echo "Discos: $(val DISCOS)"
    [ "$(val VIRT)" = none ] || echo "Rodando dentro de uma maquina virtual ($(val VIRT))"
    echo
    echo "Perfil em uso: $(val PERFIL_ATUAL)   |   Recomendado: $(val RECOMENDADO)"
}

# interface mais leve para o usuario atual (sem sombras/transparencia)
visual_leve() {
    command -v xfconf-query >/dev/null || return 0
    xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s false 2>/dev/null \
        || xfconf-query -c xfwm4 -p /general/use_compositing -s false 2>/dev/null || true
}

while true; do
    INFO=$(bash "$AP" info 2>/dev/null)
    rec=$(val RECOMENDADO)
    esc=$(zenity --list --no-markup --title="$TITULO" --width=620 --height=520 \
        --text="$(resumo)" \
        --column="id" --column="O que fazer" --hide-column=1 --print-column=1 \
        auto        "Otimizar automaticamente (recomendado para este PC: $rec)" \
        leve        "Perfil Leve (pouca memoria ou PC antigo)" \
        equilibrado "Perfil Equilibrado (uso do dia a dia)" \
        desempenho  "Perfil Desempenho (bastante memoria, quer velocidade)" \
        liberar     "Liberar memoria agora" \
        limpar      "Limpar o cache do usuario" \
        detalhes    "Ver detalhes do computador" \
        restaurar   "Voltar tudo ao padrao") || exit 0

    case "$esc" in
    auto|leve|equilibrado|desempenho)
        saida=$(como_root "$esc") || saida="Nao foi possivel aplicar (senha incorreta ou cancelado)."
        visual_leve
        zenity --info --no-markup --title="$TITULO" --width=520 --text="$saida" ;;
    restaurar)
        saida=$(como_root restaurar) || saida="Nao foi possivel restaurar."
        zenity --info --no-markup --title="$TITULO" --width=520 --text="$saida" ;;
    liberar)
        antes=$(ram_livre)
        if como_root liberar >/dev/null; then
            zenity --info --no-markup --title="$TITULO" --text="Memoria livre: $antes MB -> $(ram_livre) MB"
        else
            zenity --error --no-markup --title="$TITULO" --text="Nao consegui liberar a memoria (sem permissao)."
        fi ;;
    limpar)
        antes=$(du -sm "$HOME/.cache" 2>/dev/null | cut -f1)
        find "$HOME/.cache" -mindepth 1 -delete 2>/dev/null
        depois=$(du -sm "$HOME/.cache" 2>/dev/null | cut -f1)
        zenity --info --no-markup --title="$TITULO" \
            --text="Cache do usuario: ${antes:-0} MB -> ${depois:-0} MB" ;;
    detalhes)
        { echo "=== Computador ==="; bash "$AP" info
          echo; echo "=== Memoria (MB) ==="; free -m
          echo; echo "=== Memoria comprimida (zram) ==="; zramctl 2>&1
          echo; echo "=== Ajustes atuais ==="
          for f in /proc/sys/vm/swappiness /proc/sys/vm/vfs_cache_pressure \
                   /proc/sys/vm/dirty_ratio /sys/kernel/mm/transparent_hugepage/enabled; do
              echo "$f = $(cat "$f" 2>/dev/null)"
          done
        } | zenity --text-info --title="$TITULO" --width=680 --height=520 ;;
    esac
done
