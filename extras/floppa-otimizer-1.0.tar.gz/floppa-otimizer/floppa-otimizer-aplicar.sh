#!/bin/bash
# floppa-otimizer-aplicar.sh - a parte do Floppa Otimizer (extra) que mexe no sistema (roda como root).
#
#   floppa-otimizer-aplicar.sh info          mostra o hardware e o perfil recomendado (qualquer usuario)
#   floppa-otimizer-aplicar.sh recomendar    imprime so o nome do perfil recomendado
#   floppa-otimizer-aplicar.sh auto          aplica o perfil recomendado para este computador
#   floppa-otimizer-aplicar.sh leve|equilibrado|desempenho
#   floppa-otimizer-aplicar.sh liberar       libera memoria (descarrega o cache de arquivos)
#   floppa-otimizer-aplicar.sh restaurar     volta tudo ao que era antes da otimizacao
#
# Tudo que e alterado e anotado em /var/lib/meuos/otimizador/original, entao "restaurar"
# desfaz exatamente. So mexe em ajustes de memoria, disco e processador (nada de arquivos).
# Usa os mesmos arquivos de estado do Floppa Otimizer que vem no sistema (1.02 em diante),
# entao os dois podem ser usados juntos sem se atrapalhar.

CONF=/etc/meuos/otimizer.conf
EST=/var/lib/meuos/otimizador
ORIG=$EST/original

ram_mb()  { awk '/^MemTotal:/ {printf "%d", $2/1024}' /proc/meminfo; }
virt()    { local v; v=$(systemd-detect-virt 2>/dev/null || true); echo "${v:-none}"; }

cpu_nome() {
    sed -n 's/^model name[[:space:]]*:[[:space:]]*//p' /proc/cpuinfo | head -n1
}

gpu_info() {
    local c v drv nome fb
    for c in /sys/class/drm/card[0-9]; do
        [ -e "$c/device/vendor" ] || continue
        v=$(cat "$c/device/vendor" 2>/dev/null)
        drv=$(basename "$(readlink -f "$c/device/driver" 2>/dev/null)" 2>/dev/null)
        case "$v" in
            0x10de) nome="NVIDIA" ;;
            0x1002) nome="AMD" ;;
            0x8086) nome="Intel" ;;
            0x80ee) nome="VirtualBox" ;;
            0x15ad) nome="VMware" ;;
            0x1234) nome="QEMU/Bochs" ;;
            0x1af4) nome="virtio" ;;
            *)      nome="desconhecida ($v)" ;;
        esac
        echo "$nome${drv:+ (driver: $drv)}"
        return
    done
    fb=$(cat /sys/class/graphics/fb0/name 2>/dev/null)
    echo "video basico${fb:+ ($fb)}"
}

discos() {
    local d n r tipo mb saida=""
    for d in /sys/block/*; do
        n=${d##*/}
        case "$n" in loop*|sr*|ram*|zram*|fd*|dm-*) continue ;; esac
        r=$(cat "$d/queue/rotational" 2>/dev/null)
        [ "$r" = 1 ] && tipo=HDD || tipo=SSD
        mb=$(( $(cat "$d/size" 2>/dev/null || echo 0) / 2048 ))
        saida="$saida$n: $tipo $((mb / 1024)) GB; "
    done
    echo "${saida:-nenhum}"
}

recomendar() {
    local r c
    r=$(ram_mb); c=$(nproc)
    if [ "$r" -lt 2200 ] || { [ "$c" -le 2 ] && [ "$r" -lt 4000 ]; }; then
        echo leve
    elif [ "$r" -lt 6000 ]; then
        echo equilibrado
    else
        echo desempenho
    fi
}

perfil_atual() {
    local p
    p=$(sed -n 's/^PERFIL=//p' "$CONF" 2>/dev/null | head -n1)
    echo "${p:-desligado}"
}

info() {
    echo "RAM_MB=$(ram_mb)"
    echo "CPUS=$(nproc)"
    echo "CPU=$(cpu_nome)"
    echo "VIRT=$(virt)"
    echo "GPU=$(gpu_info)"
    echo "DISCOS=$(discos)"
    echo "PERFIL_ATUAL=$(perfil_atual)"
    echo "RECOMENDADO=$(recomendar)"
}

precisa_root() {
    [ "$EUID" -eq 0 ] || { echo "ERRO: precisa ser root (use o Floppa Otimizer)."; exit 1; }
}

# ajustar CAMINHO VALOR - guarda o valor original uma unica vez e grava o novo
ajustar() {
    local cam=$1 val=$2 atual
    [ -w "$cam" ] || return 0
    atual=$(cat "$cam" 2>/dev/null) || return 0
    case "$atual" in *\[*\]*) atual=$(echo "$atual" | sed 's/.*\[\(.*\)\].*/\1/') ;; esac
    mkdir -p "$EST"
    grep -q "^$cam=" "$ORIG" 2>/dev/null || echo "$cam=$atual" >> "$ORIG"
    if echo "$val" > "$cam" 2>/dev/null; then
        echo "  $cam = $val"
    fi
}

desfazer_valores() {
    local linha cam val
    [ -f "$ORIG" ] || return 0
    while IFS= read -r linha; do
        cam=${linha%%=*}; val=${linha#*=}
        [ -w "$cam" ] && echo "$val" > "$cam" 2>/dev/null
    done < "$ORIG"
}

aplicar_perfil() {
    local p=$1 sw vfs dr db thp gov d n r ra sch g
    case "$p" in
        leve)        sw=150; vfs=100; dr=10; db=5;  thp=never;   gov="" ;;
        equilibrado) sw=100; vfs=50;  dr=15; db=5;  thp=madvise; gov="" ;;
        desempenho)  sw=40;  vfs=50;  dr=30; db=10; thp=madvise; gov=performance ;;
        *) echo "ERRO: perfil desconhecido: $p"; exit 2 ;;
    esac

    # volta ao original antes de aplicar o novo (assim trocar de perfil nao acumula mudancas)
    desfazer_valores

    echo "Perfil: $p"
    ajustar /proc/sys/vm/swappiness "$sw"
    ajustar /proc/sys/vm/vfs_cache_pressure "$vfs"
    ajustar /proc/sys/vm/dirty_ratio "$dr"
    ajustar /proc/sys/vm/dirty_background_ratio "$db"
    ajustar /sys/kernel/mm/transparent_hugepage/enabled "$thp"

    # discos fisicos: escalonador e leitura antecipada conforme HDD ou SSD
    for d in /sys/block/*; do
        n=${d##*/}
        case "$n" in loop*|sr*|ram*|zram*|fd*|dm-*) continue ;; esac
        r=$(cat "$d/queue/rotational" 2>/dev/null)
        if [ "$r" = 1 ]; then sch=mq-deadline; ra=1024; else sch=none; ra=256; fi
        grep -qw "$sch" "$d/queue/scheduler" 2>/dev/null && ajustar "$d/queue/scheduler" "$sch"
        ajustar "$d/queue/read_ahead_kb" "$ra"
    done

    # processador: so no "desempenho" e so em maquina real (VM nao tem controle de frequencia)
    if [ -n "$gov" ]; then
        for g in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor; do
            [ -e "$g" ] || continue
            grep -qw "$gov" "${g%scaling_governor}scaling_available_governors" 2>/dev/null \
                && ajustar "$g" "$gov"
        done
    fi
}

salvar_perfil() {
    mkdir -p "$(dirname "$CONF")"
    echo "PERFIL=$1" > "$CONF"
}

liberar_memoria() {
    sync
    echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
    echo 1 > /proc/sys/vm/compact_memory 2>/dev/null
    return 0
}

case "$1" in
    info)       info ;;
    recomendar) recomendar ;;
    auto)       precisa_root; p=$(recomendar); aplicar_perfil "$p"; salvar_perfil auto
                echo "Pronto: perfil $p aplicado (automatico)." ;;
    leve|equilibrado|desempenho)
                precisa_root; aplicar_perfil "$1"; salvar_perfil "$1"
                echo "Pronto: perfil $1 aplicado." ;;
    liberar)    precisa_root; liberar_memoria ;;
    restaurar)  precisa_root; desfazer_valores; rm -f "$ORIG"; salvar_perfil desligado
                echo "Pronto: tudo voltou ao padrao do sistema." ;;
    *)          sed -n '2,13p' "$0" | sed 's/^# \{0,1\}//'; exit 1 ;;
esac
exit 0
