# -*- coding: utf-8 -*-
"""O Floppa: assistente virtual do FloppyMakes. Chato de proposito (igual ao Clippy).

- Fica de olho no que voce digita e pergunta tudo quando ve uma palavra-chave (palavras.json).
- Pergunta coisas aleatorias de tempos em tempos e insiste se voce nao responde.
- Mas voce manda: menu Floppa > nivel (chato / normal / quieto / mudo).
"""
import json
import os
import random
import re
import time
import tkinter as tk
import unicodedata
from tkinter import ttk

GIF = "/usr/share/meuos/floppa/floppa.gif"
COR_BALAO = "#FFF8C6"
# Emojis ficam de fora: o Tk trava (erro do X11) quando a fonte de emoji colorido aparece.
EMOJI = re.compile("[\u2190-\u2BFF\U0001F000-\U0010FFFF\uFE0F\u200d]")


def limpo(s):
    s = EMOJI.sub("", s)
    return re.sub(r"[ ]{2,}", " ", s).replace(" !", "!").replace(" ?", "?").strip()


def norm(s):
    s = unicodedata.normalize("NFD", s.lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def casa(chave, texto, fim=False):
    """A palavra-chave aparece como palavra inteira (e, se fim=True, no final do texto)?"""
    padrao = r"(?<![a-z0-9])" + re.escape(chave) + (r"$" if fim else r"(?![a-z0-9])")
    return re.search(padrao, texto) is not None


class Floppa(ttk.Frame):
    # segundos de silencio ate o Floppa puxar assunto sozinho (None = nunca)
    ASSUNTO = {"chato": 40, "normal": 120, "quieto": None, "mudo": None}
    ESPERA_PALAVRA = {"chato": 90, "normal": 240, "quieto": 240, "mudo": 240}

    def __init__(self, mestre, pasta, acoes, config, salvar_config):
        super().__init__(mestre, padding=6)
        with open(os.path.join(pasta, "palavras.json"), encoding="utf-8") as f:
            self.d = json.load(f)
        # acoes: inserir(texto, linguagem, sala), abrir(cmd), sala(nome), salvar() -> bool
        self.acoes = acoes
        self.cfg = config
        self.salvar_config = salvar_config
        self.nivel = config.get("floppa_nivel", "chato")
        if self.nivel not in self.ASSUNTO:
            self.nivel = "chato"
        self.pendente = False
        self.cutucadas = 0
        self.texto_atual = ""
        self.ultima_fala = time.time()
        self.ultima_tecla = time.time()
        self.espera = {}
        self.frames = []
        self.quadro = 0
        self._montar()
        self._carregar_gif()
        self.after(100, self._animar)
        self.after(1200, self.cumprimentar)
        self.after(5000, self._tick)

    # ------------------------------------------------------------ visual
    def _montar(self):
        ttk.Label(self, text="Floppa", font=("TkDefaultFont", 12, "bold")).pack()
        self.foto = tk.Label(self, cursor="hand2", text="(Floppa)")
        self.foto.pack(pady=4)
        self.foto.bind("<Button-1>", lambda e: self.cutucar())
        self.balao = tk.Label(self, text="", bg=COR_BALAO, fg="black", wraplength=210,
                              justify="left", relief="solid", bd=1, padx=8, pady=6)
        self.balao.pack(fill="x", pady=4)
        self.botoes = ttk.Frame(self)
        self.botoes.pack(fill="x")
        ttk.Label(self, text="Fale com o Floppa:").pack(anchor="w", pady=(10, 0))
        self.entrada = ttk.Entry(self)
        self.entrada.pack(fill="x")
        self.entrada.bind("<Return>", self._falou)
        ttk.Label(self, text="(escreva uma palavra-chave e Enter)",
                  font=("TkDefaultFont", 8)).pack(anchor="w")

    def _carregar_gif(self):
        if not os.path.isfile(GIF):
            return
        fator = 1
        for i in range(120):
            try:
                img = tk.PhotoImage(file=GIF, format="gif -index %d" % i)
            except tk.TclError:
                break
            if i == 0:
                fator = max(1, -(-img.width() // 200))   # encolhe para ~200 px de largura
            self.frames.append(img.subsample(fator, fator) if fator > 1 else img)
        if self.frames:
            self.foto.configure(image=self.frames[0], text="")

    def _animar(self):
        if len(self.frames) > 1:
            self.quadro = (self.quadro + 1) % len(self.frames)
            self.foto.configure(image=self.frames[self.quadro])
            self.after(70, self._animar)

    # ------------------------------------------------------------ falar / perguntar
    def _limpar_botoes(self):
        for w in self.botoes.winfo_children():
            w.destroy()

    def _mostrar(self, texto):
        self.texto_atual = limpo(texto)
        self.balao.configure(text=self.texto_atual)
        self.ultima_fala = time.time()

    def falar(self, texto):
        self._limpar_botoes()
        self.pendente = False
        self.cutucadas = 0
        self._mostrar(texto)

    def perguntar(self, texto, opcoes):
        """opcoes: lista de (rotulo, funcao)."""
        self._limpar_botoes()
        self._mostrar(texto)
        for rotulo, fn in opcoes:
            ttk.Button(self.botoes, text=limpo(rotulo),
                       command=lambda f=fn: self._clicou(f)).pack(fill="x", pady=1)
        self.pendente = True
        self.cutucadas = 0

    def _clicou(self, fn):
        self._limpar_botoes()
        self.pendente = False
        self.ultima_fala = time.time()
        fn()

    # ------------------------------------------------------------ conversa
    def cumprimentar(self):
        if self.nivel == "mudo":
            return
        self.perguntar(self.d["saudacao"], [("Sim!", self._sim_inicial), ("Nao", self._nao_inicial)])

    def _sim_inicial(self):
        self.falar(self.d["sim_inicial"])

    def _nao_inicial(self):
        self.perguntar(self.d["nao_inicial"], [
            ("Tenho certeza", lambda: self.falar(self.d["tenho_certeza"])),
            ("Ok, quero ajuda", self._sim_inicial)])

    def cutucar(self):
        """Clicou no Floppa: ele aproveita para perguntar alguma coisa."""
        self._item(random.choice(self.d["aleatorias"]))

    def _item(self, item):
        sim = item.get("sim", "Sim, por favor!")
        self.perguntar(item["pergunta"], [
            (sim, lambda: self._executar(item["acao"])),
            ("Nao", lambda: self._nao(item))])

    def _nao(self, item):
        if random.random() < 0.4:
            self.perguntar("Tem certeza?? Eu caprichei nisso...", [
                ("Tenho", lambda: self.falar(random.choice(self.d["nao_respostas"]))),
                ("Ok, mostra", lambda: self._executar(item["acao"]))])
        else:
            self.falar(random.choice(self.d["nao_respostas"]))

    def _executar(self, a):
        tipo = a.get("tipo")
        if tipo == "dizer":
            self.falar(a["texto"])
        elif tipo == "ideia":
            self.falar(random.choice(self.d["ideias"]))
        elif tipo == "curiosidade":
            self.falar(random.choice(self.d["curiosidades"]))
        elif tipo == "inserir":
            self.acoes["inserir"](a["texto"], a.get("linguagem"), a.get("sala"))
            self.falar("Pronto! Coloquei no seu texto. Pode editar o que quiser!")
        elif tipo == "abrir":
            self.acoes["abrir"](a["comando"])
            self.falar("Abrindo! Demora um pouquinho, ta?")
        elif tipo == "sala":
            self.acoes["sala"](a["sala"])
            self.falar("Pronto, te levei pra la!")
        elif tipo == "salvar":
            self.falar("Salvei!" if self.acoes["salvar"]() else "Nao tinha nada pra salvar... ainda.")
        self.after(7000, self._mais)

    def _mais(self):
        """Depois de ajudar, o Floppa pergunta se quer mais. Sempre."""
        if self.pendente or self.nivel == "mudo" or time.time() - self.ultima_fala < 6:
            return
        self.perguntar(self.d["mais"], [
            ("Sim", lambda: self.falar(self.d["mais_sim"])),
            ("Nao", lambda: self.falar(self.d["mais_nao"]))])

    # ------------------------------------------------------------ palavras-chave
    def _achar(self, texto):
        t = norm(texto)
        for e in self.d["palavras"]:
            if any(casa(k, t) for k in e["chaves"]):
                return e
        return None

    def _falou(self, _ev=None):
        texto = self.entrada.get().strip()
        self.entrada.delete(0, "end")
        if not texto:
            return
        t = norm(texto)
        if any(casa(p, t) for p in ("cala", "silencio", "quieto", "chega")):
            self.definir_nivel("quieto")
            return
        e = self._achar(texto)
        if e:
            self._item(e)
        else:
            self.falar(self.d["desconhecido"])

    def digitou(self, widget):
        """Chamado a cada tecla solta numa area de texto: procura palavra-chave recem-digitada."""
        self.ultima_tecla = time.time()
        if self.nivel == "mudo" or self.pendente or time.time() - self.ultima_fala < 8:
            return
        linha = widget.get("insert linestart", "insert")
        if not linha or linha[-1].isalnum():
            return                                  # so quando a palavra terminou (espaco, ponto...)
        cauda = re.sub(r"[^a-z0-9]+$", "", norm(linha)[-40:])
        for e in self.d["palavras"]:
            chave = e["chaves"][0]
            if time.time() < self.espera.get(chave, 0):
                continue
            if any(casa(k, cauda, fim=True) for k in e["chaves"]):
                self.espera[chave] = time.time() + self.ESPERA_PALAVRA[self.nivel]
                self._item(e)
                return

    # ------------------------------------------------------------ nivel de chatice
    def definir_nivel(self, nivel):
        self.nivel = nivel
        self.cfg["floppa_nivel"] = nivel
        self.salvar_config()
        msgs = {
            "chato": "Eba!! Agora eu vou perguntar TUDO! Tudo tudo tudo!",
            "normal": "Ok, vou perguntar menos. Um pouquinho menos.",
            "quieto": "Ta bom... so ajudo se voce digitar palavras-chave. Eu fico quietinho.",
            "mudo": "Ta bom. (Silencio total. Me clica se precisar de mim.)",
        }
        self.falar(msgs[nivel])

    # ------------------------------------------------------------ relogio
    def _tick(self):
        agora = time.time()
        if self.nivel != "mudo":
            if self.pendente:
                if self.nivel in ("chato", "normal") and agora - self.ultima_fala > 25:
                    if self.cutucadas < 2:
                        self.cutucadas += 1
                        self.balao.configure(
                            text=limpo(random.choice(self.d["insistir"])) + "\n\n" + self.texto_atual)
                        self.ultima_fala = agora
                    else:
                        self.falar(self.d["desistir"])
            else:
                espera = self.ASSUNTO[self.nivel]
                if espera and agora - self.ultima_fala > espera:
                    parado = agora - self.ultima_tecla > 20
                    lista = self.d["ocioso"] if parado and random.random() < 0.6 else self.d["aleatorias"]
                    self._item(random.choice(lista))
        self.after(5000, self._tick)
