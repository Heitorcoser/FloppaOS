#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""FloppyMakes - um "World" do MeuOS.

Tres salas para criar coisas, com o Floppa (assistente virtual chato) sempre por perto:
  Oficina  - escreva e rode programas em Python, JavaScript, FloopyC e shell
  Caderno  - bloco de notas (salva sozinho)
  Quadro   - desenho livre
Seus arquivos ficam em ~/FloppyMakes (ou ~/Compartilhada/FloppyMakes, se a pasta
compartilhada estiver ligada - assim nao somem ao desligar a VM).
"""
import json
import os
import queue
import shlex
import shutil
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
from floppa import Floppa  # noqa: E402

HOME = os.path.expanduser("~")
COMP = os.path.join(HOME, "Compartilhada")
BASE = os.path.join(COMP if os.path.ismount(COMP) else HOME, "FloppyMakes")
PROJETOS = os.path.join(BASE, "projetos")
DESENHOS = os.path.join(BASE, "desenhos")
CONFIG = os.path.join(BASE, "config.json")
CADERNO = os.path.join(BASE, "caderno.txt")

# nome: (extensao, comando, modelo inicial)
LINGS = {
    "Python": (".py", ["python3"], "# Python\nprint('Ola do FloppyMakes!')\n"),
    "JavaScript": (".js", ["node"], "// JavaScript\nconsole.log('Ola do FloppyMakes!');\n"),
    "FloopyC": (".flp", ["floopyc"],
                "-- FloopyC\nSayBin(\"Ola do FloppyMakes!\");\nSpeakFlp(\"Ola! Eu sou o Floppa.\");\n"),
    "Shell": (".sh", ["bash"], "#!/bin/bash\necho 'Ola do FloppyMakes!'\n"),
}
SALAS = {"oficina": 0, "caderno": 1, "quadro": 2}


def carregar_config():
    try:
        with open(CONFIG, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("FloppyMakes - o mundo onde tudo se faz")
        self.geometry("1020x660")
        for p in (PROJETOS, DESENHOS):
            os.makedirs(p, exist_ok=True)
        self.cfg = carregar_config()
        self.arquivo = None
        self.proc = None
        self.fila = queue.Queue()
        self.pontos = 0
        self.comentou_desenho = False
        self.caderno_sujo = False

        self._menu()
        corpo = ttk.Frame(self)
        corpo.pack(fill="both", expand=True)
        self.floppa = Floppa(corpo, AQUI, {
            "inserir": self.inserir, "abrir": self.lancar,
            "sala": self.ir, "salvar": self.salvar_tudo,
            "linguagem": lambda: self.lingua.get(),
        }, self.cfg, self.salvar_cfg)
        self.floppa.pack(side="right", fill="y")
        self.abas = ttk.Notebook(corpo)
        self.abas.pack(side="left", fill="both", expand=True)
        self._oficina()
        self._caderno()
        self._quadro()

        self.bind("<Control-s>", lambda e: self.salvar())
        self.protocol("WM_DELETE_WINDOW", self.sair)
        self.after(100, self._bombear)
        self.after(30000, self._autosalvar)

    # ------------------------------------------------------------ geral
    def salvar_cfg(self):
        try:
            with open(CONFIG, "w", encoding="utf-8") as f:
                json.dump(self.cfg, f)
        except OSError:
            pass

    def ir(self, sala):
        self.abas.select(SALAS.get(sala, 0))

    def lancar(self, comando):
        try:
            subprocess.Popen(shlex.split(comando), stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
        except OSError as e:
            messagebox.showerror("FloppyMakes", "Nao consegui abrir:\n%s\n\n%s" % (comando, e))

    def _menu(self):
        m = tk.Menu(self)
        arq = tk.Menu(m, tearoff=0)
        arq.add_command(label="Novo programa", command=self.novo)
        arq.add_command(label="Abrir...", command=self.abrir)
        arq.add_command(label="Salvar", command=self.salvar, accelerator="Ctrl+S")
        arq.add_separator()
        arq.add_command(label="Sair", command=self.sair)
        m.add_cascade(label="Arquivo", menu=arq)

        mundo = tk.Menu(m, tearoff=0)
        for nome, sala in (("Oficina", "oficina"), ("Caderno", "caderno"), ("Quadro", "quadro")):
            mundo.add_command(label="Ir para: " + nome, command=lambda s=sala: self.ir(s))
        mundo.add_separator()
        mundo.add_command(label="Jogos do Floppa",
                          command=lambda: self.lancar("xfce4-terminal -x floppagames"))
        mundo.add_command(label="Floppa Studio", command=lambda: self.lancar("meuos-estudio"))
        mundo.add_command(label="Windows (jogos e programas .exe)",
                          command=lambda: self.lancar("meuos-windows --menu"))
        m.add_cascade(label="Mundo", menu=mundo)

        fl = tk.Menu(m, tearoff=0)
        self.var_nivel = tk.StringVar(value=self.cfg.get("floppa_nivel", "chato"))
        for n, t in (("chato", "Chato (pergunta tudo)"), ("normal", "Normal"),
                     ("quieto", "Quieto (so palavras-chave)"), ("mudo", "Mudo")):
            fl.add_radiobutton(label=t, value=n, variable=self.var_nivel,
                               command=lambda: self.floppa.definir_nivel(self.var_nivel.get()))
        fl.add_separator()
        fl.add_command(label="Chamar o Floppa", command=lambda: self.floppa.cutucar())
        m.add_cascade(label="Floppa", menu=fl)
        self.config(menu=m)

    # ------------------------------------------------------------ Oficina
    def _oficina(self):
        f = ttk.Frame(self.abas)
        self.abas.add(f, text="Oficina")
        barra = ttk.Frame(f)
        barra.pack(fill="x", padx=6, pady=4)
        ttk.Label(barra, text="Linguagem:").pack(side="left")
        self.lingua = tk.StringVar(value="Python")
        cb = ttk.Combobox(barra, textvariable=self.lingua, values=list(LINGS),
                          state="readonly", width=12)
        cb.pack(side="left", padx=4)
        cb.bind("<<ComboboxSelected>>", lambda e: self._trocou_lingua())
        self.no_terminal = tk.BooleanVar(value=False)
        ttk.Checkbutton(barra, text="Rodar no terminal", variable=self.no_terminal).pack(
            side="left", padx=8)
        ttk.Button(barra, text="Rodar", command=self.rodar).pack(side="left", padx=2)
        ttk.Button(barra, text="Parar", command=self.parar).pack(side="left", padx=2)
        self.rotulo_arq = ttk.Label(barra, text="(sem nome)")
        self.rotulo_arq.pack(side="right")

        painel = ttk.PanedWindow(f, orient="vertical")
        painel.pack(fill="both", expand=True, padx=6, pady=(0, 6))
        self.editor = tk.Text(painel, wrap="none", undo=True, font=("monospace", 11), height=18)
        self.saida = tk.Text(painel, wrap="word", font=("monospace", 10), height=8,
                             bg="#1e1e1e", fg="#e0e0e0", state="disabled")
        painel.add(self.editor, weight=3)
        painel.add(self.saida, weight=1)
        self.editor.insert("1.0", LINGS["Python"][2])
        self.editor.bind("<KeyRelease>", lambda e: self.floppa.digitou(self.editor))

    def _so_modelo(self, texto):
        return texto.strip() == "" or any(texto == t[2] for t in LINGS.values())

    def _trocou_lingua(self):
        if self._so_modelo(self.editor.get("1.0", "end-1c")):
            self.editor.delete("1.0", "end")
            self.editor.insert("1.0", LINGS[self.lingua.get()][2])
        self.arquivo = None
        self.rotulo_arq.config(text="(sem nome)")

    def novo(self):
        self.ir("oficina")
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", LINGS[self.lingua.get()][2])
        self.arquivo = None
        self.rotulo_arq.config(text="(sem nome)")

    def abrir(self):
        caminho = filedialog.askopenfilename(initialdir=PROJETOS, title="Abrir programa")
        if not caminho:
            return
        try:
            with open(caminho, encoding="utf-8") as f:
                texto = f.read()
        except (OSError, UnicodeDecodeError) as e:
            messagebox.showerror("FloppyMakes", "Nao consegui abrir:\n%s" % e)
            return
        ext = os.path.splitext(caminho)[1].lower()
        for nome, (e, _c, _t) in LINGS.items():
            if e == ext:
                self.lingua.set(nome)
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", texto)
        self.arquivo = caminho
        self.rotulo_arq.config(text=os.path.basename(caminho))
        self.ir("oficina")

    def salvar(self, silencioso=False):
        ext = LINGS[self.lingua.get()][0]
        if not self.arquivo:
            if silencioso:
                self.arquivo = os.path.join(PROJETOS, "sem-nome" + ext)
            else:
                caminho = filedialog.asksaveasfilename(
                    initialdir=PROJETOS, defaultextension=ext, title="Salvar programa",
                    filetypes=[("Programa", "*" + ext), ("Todos", "*")])
                if not caminho:
                    return False
                self.arquivo = caminho
        try:
            with open(self.arquivo, "w", encoding="utf-8") as f:
                f.write(self.editor.get("1.0", "end-1c"))
        except OSError as e:
            messagebox.showerror("FloppyMakes", "Nao consegui salvar:\n%s" % e)
            return False
        self.rotulo_arq.config(text=os.path.basename(self.arquivo))
        return True

    def salvar_tudo(self):
        ok = self.salvar(silencioso=True)
        self._salvar_caderno()
        return ok

    def inserir(self, texto, linguagem=None, sala=None):
        """Usado pelo Floppa: poe um exemplo na Oficina (ou no Caderno)."""
        if sala == "caderno":
            self.ir("caderno")
            alvo = self.caderno
        else:
            self.ir("oficina")
            if linguagem in LINGS and linguagem != self.lingua.get():
                self.lingua.set(linguagem)
                self.arquivo = None
                self.rotulo_arq.config(text="(sem nome)")
            alvo = self.editor
        atual = alvo.get("1.0", "end-1c")
        if alvo is self.editor and self._so_modelo(atual):
            alvo.delete("1.0", "end")
            alvo.insert("1.0", texto)
        else:
            alvo.insert("end-1c", ("\n\n" if atual.strip() else "") + texto)
        alvo.see("end")

    def rodar(self):
        nome = self.lingua.get()
        _ext, cmd, _modelo = LINGS[nome]
        if not self.salvar(silencioso=True):
            return
        if not shutil.which(cmd[0]):
            messagebox.showerror("FloppyMakes", "Nao encontrei o programa '%s'." % cmd[0])
            return
        codigo = self.editor.get("1.0", "end-1c")
        terminal = (self.no_terminal.get() or nome == "FloopyC"
                    or "input(" in codigo or "readline" in codigo)
        self.parar()
        if terminal:
            self.lancar(" ".join(["xfce4-terminal", "--hold", "-x"]
                                 + [shlex.quote(c) for c in cmd + [self.arquivo]]))
            self._escrever("[abri no terminal: %s]\n" % os.path.basename(self.arquivo), limpar=True)
            return
        self._escrever("", limpar=True)
        try:
            self.proc = subprocess.Popen(
                cmd + [self.arquivo], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL, text=True, bufsize=1,
                cwd=os.path.dirname(self.arquivo))
        except OSError as e:
            self._escrever("Erro ao rodar: %s\n" % e)
            return
        threading.Thread(target=self._ler, args=(self.proc,), daemon=True).start()

    def _ler(self, proc):
        for linha in proc.stdout:
            self.fila.put(linha)
        proc.wait()
        self.fila.put("\n[terminou - codigo %d]\n" % proc.returncode)

    def parar(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()

    def _escrever(self, texto, limpar=False):
        self.saida.configure(state="normal")
        if limpar:
            self.saida.delete("1.0", "end")
        self.saida.insert("end", texto)
        self.saida.see("end")
        self.saida.configure(state="disabled")

    def _bombear(self):
        try:
            while True:
                self._escrever(self.fila.get_nowait())
        except queue.Empty:
            pass
        self.after(100, self._bombear)

    # ------------------------------------------------------------ Caderno
    def _caderno(self):
        f = ttk.Frame(self.abas)
        self.abas.add(f, text="Caderno")
        sb = ttk.Scrollbar(f)
        sb.pack(side="right", fill="y")
        self.caderno = tk.Text(f, wrap="word", undo=True, font=("TkDefaultFont", 12),
                               yscrollcommand=sb.set)
        sb.config(command=self.caderno.yview)
        self.caderno.pack(fill="both", expand=True)
        try:
            with open(CADERNO, encoding="utf-8") as fh:
                self.caderno.insert("1.0", fh.read())
        except OSError:
            pass
        self.caderno.bind("<KeyRelease>", self._caderno_tecla)

    def _caderno_tecla(self, _e):
        self.caderno_sujo = True
        self.floppa.digitou(self.caderno)

    def _salvar_caderno(self):
        try:
            with open(CADERNO, "w", encoding="utf-8") as f:
                f.write(self.caderno.get("1.0", "end-1c"))
            self.caderno_sujo = False
        except OSError:
            pass

    def _autosalvar(self):
        if self.caderno_sujo:
            self._salvar_caderno()
        self.after(30000, self._autosalvar)

    # ------------------------------------------------------------ Quadro
    def _quadro(self):
        f = ttk.Frame(self.abas)
        self.abas.add(f, text="Quadro")
        barra = ttk.Frame(f)
        barra.pack(fill="x", padx=6, pady=4)
        self.cor = "black"
        for nome, cor, letra in (("Preto", "black", "white"), ("Vermelho", "red", "white"),
                                 ("Azul", "blue", "white"), ("Verde", "green", "white"),
                                 ("Amarelo", "gold", "black"), ("Borracha", "white", "black")):
            tk.Button(barra, text=nome, bg=cor, fg=letra,
                      command=lambda c=cor: setattr(self, "cor", c)).pack(side="left", padx=2)
        self.espessura = tk.Scale(barra, from_=1, to=30, orient="horizontal",
                                  label="Tamanho", length=140)
        self.espessura.set(4)
        self.espessura.pack(side="left", padx=8)
        ttk.Button(barra, text="Limpar", command=lambda: self.tela.delete("all")).pack(side="left")
        ttk.Button(barra, text="Salvar desenho", command=self.salvar_desenho).pack(side="left", padx=4)
        self.tela = tk.Canvas(f, bg="white", highlightthickness=1, cursor="pencil")
        self.tela.pack(fill="both", expand=True, padx=6, pady=(0, 6))
        self.tela.bind("<ButtonPress-1>", lambda e: setattr(self, "ultimo", (e.x, e.y)))
        self.tela.bind("<B1-Motion>", self._riscar)

    def _riscar(self, e):
        x0, y0 = getattr(self, "ultimo", (e.x, e.y))
        self.tela.create_line(x0, y0, e.x, e.y, fill=self.cor, width=self.espessura.get(),
                              capstyle="round", smooth=True)
        self.ultimo = (e.x, e.y)
        self.pontos += 1
        if self.pontos > 150 and not self.comentou_desenho:
            self.comentou_desenho = True
            if self.floppa.nivel != "mudo" and not self.floppa.pendente:
                self.floppa._item({
                    "pergunta": "Que desenho lindo!! Quer que eu adivinhe o que e?",
                    "sim": "Adivinha",
                    "acao": {"tipo": "dizer", "texto": "E um gato! Eu sempre acerto."}})

    def salvar_desenho(self):
        caminho = os.path.join(DESENHOS, time.strftime("desenho-%Y%m%d-%H%M%S.ps"))
        try:
            self.tela.postscript(file=caminho, colormode="color")
            messagebox.showinfo("FloppyMakes", "Desenho salvo em:\n%s" % caminho)
        except (tk.TclError, OSError) as e:
            messagebox.showerror("FloppyMakes", "Nao consegui salvar:\n%s" % e)

    # ------------------------------------------------------------ sair
    def sair(self):
        self._salvar_caderno()
        self.salvar_cfg()
        self.parar()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
