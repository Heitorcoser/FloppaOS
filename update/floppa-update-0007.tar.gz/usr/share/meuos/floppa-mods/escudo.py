# -*- coding: utf-8 -*-
"""Floppa Escudo - a checagem de seguranca dos mods do Floppa OS.

Olha um pacote de mod (.floppamod = tar.gz com mod.json) SEM executar nada dele e diz:
    limpo      - pode instalar
    atencao    - pode instalar, mas o usuario precisa ler os avisos e confirmar
    bloqueado  - nao instala de jeito nenhum

O que confere:
  1. o pacote: tamanho, quantidade de arquivos, bomba de compressao, nomes perigosos (caminho absoluto,
     '..', caracteres invisiveis), links, dispositivos, setuid, arquivos repetidos
  2. o mod.json: id, tipo, para onde cada arquivo vai (so pastas do usuario permitidas), configuracoes
     (so as da lista branca, com valores conferidos), atalhos e o que abre ao entrar
  3. o conteudo: programas compilados (ELF/EXE), arquivos disfarcados (extensao que nao bate com o
     conteudo), pacotes dentro do pacote, o virus de teste EICAR, lista negra (sha256) e padroes de
     malware em scripts, FloopyC, .desktop, SVG e CSS
  4. o ClamAV (se estiver instalado)

Uso como programa:   python3 escudo.py PACOTE.floppamod      (mostra o relatorio em JSON)
"""
import hashlib
import io
import json
import os
import re
import shutil
import stat
import subprocess
import tarfile
import tempfile
import time
import unicodedata

VERSAO_ESCUDO = "1.0"

# ---------------------------------------------------------------- limites
LIMITE_PACOTE = 150 * 1024 * 1024          # tamanho do .floppamod
LIMITE_TOTAL = 300 * 1024 * 1024           # tudo descomprimido
LIMITE_ARQUIVO = 100 * 1024 * 1024         # um arquivo so
LIMITE_ARQUIVOS = 5000                     # quantidade de arquivos
LIMITE_PROPORCAO = 120                     # descomprimido / comprimido (bomba de compressao)
LIMITE_MANIFESTO = 64 * 1024
LIMITE_TEXTO_ANALISE = 4 * 1024 * 1024     # le no maximo 4 MB de cada texto para os padroes
LIMITE_TEMPO = 3600                        # a checagem inteira tem no maximo 1 hora
LIMITE_CAMINHO = 1024
LIMITE_NOME = 255

NIVEIS = {"info": 0, "atencao": 1, "bloqueado": 2}

TIPOS = {"tema", "icones", "cursor", "fundos", "fontes", "painel", "visual", "busca", "jogo",
         "programa", "script", "atalhos", "pacote"}

# para onde um mod pode mandar arquivos (sempre dentro da pasta pessoal; o gerenciador decide o caminho real)
DESTINOS = {
    "fundos": {".png", ".jpg", ".jpeg", ".svg", ".webp"},
    "temas": None,          # tema GTK/xfwm4 (pastas de tema): css, png, svg, rc, xpm, index.theme
    "icones": None,
    "cursores": None,
    "fontes": {".ttf", ".otf", ".woff", ".woff2"},
    "programas": None,      # arquivos do proprio mod (jogos .flp, scripts, imagens)
    "busca": {".rasi"},
    "gtk-css": {".css"},
    "sons": {".ogg", ".oga", ".wav"},
}
EXT_TEMA = {".css", ".png", ".svg", ".rc", ".xpm", ".theme", ".xml", ".jpg", ".gif", ".scss", ".txt",
            ".md", ".json", ".ini", ""}
EXT_PROGRAMA = {".flp", ".sh", ".py", ".txt", ".md", ".json", ".png", ".jpg", ".jpeg", ".svg", ".ogg",
                ".oga", ".wav", ".csv", ".tsv", ".ini", ".rasi", ".css"}
EXECUTAVEIS = {".flp": "floopyc", ".sh": "bash", ".py": "python3"}

# configuracoes do XFCE que um mod pode mudar: canal -> {propriedade: (tipo, conferencia)}
_COR = re.compile(r"^[A-Za-z0-9 _.+-]{1,80}$")
LISTA_BRANCA = {
    "xsettings": {
        "/Net/ThemeName": ("string", _COR), "/Net/IconThemeName": ("string", _COR),
        "/Gtk/FontName": ("string", _COR), "/Gtk/MonospaceFontName": ("string", _COR),
        "/Gtk/CursorThemeName": ("string", _COR), "/Gtk/CursorThemeSize": ("int", (16, 96)),
        "/Xft/DPI": ("int", (72, 192)), "/Xft/Antialias": ("int", (0, 1)),
        "/Xft/HintStyle": ("string", re.compile(r"^hint(none|slight|medium|full)$")),
        "/Net/SoundThemeName": ("string", _COR), "/Net/EnableEventSounds": ("bool", None),
    },
    "xfwm4": {
        "/general/theme": ("string", _COR), "/general/title_font": ("string", _COR),
        "/general/button_layout": ("string", re.compile(r"^[OHMCS|]{1,12}$")),
        "/general/title_alignment": ("string", re.compile(r"^(left|center|right)$")),
        "/general/use_compositing": ("bool", None), "/general/show_frame_shadow": ("bool", None),
        "/general/show_popup_shadow": ("bool", None), "/general/frame_opacity": ("int", (50, 100)),
        "/general/inactive_opacity": ("int", (50, 100)), "/general/workspace_count": ("int", (1, 12)),
    },
    "xfce4-panel": {
        "/panels/dark-mode": ("bool", None),
        "/panels/panel-1/position": ("string", re.compile(r"^p=(6|8|2|4|0);x=\d{1,4};y=\d{1,4}$")),
        "/panels/panel-1/size": ("uint", (16, 96)), "/panels/panel-1/icon-size": ("uint", (0, 64)),
        "/panels/panel-1/length": ("uint", (1, 100)),
    },
    "xfce4-notifyd": {
        "/theme": ("string", _COR), "/notify-location": ("uint", (0, 3)),
        "/expire-timeout": ("int", (1, 60)),
    },
}
VISUAIS = {"auto", "desligado", "leve", "completo"}
TECLA = re.compile(r"^(<(Super|Primary|Alt|Shift)>){1,3}([A-Za-z0-9]|F[1-9]|F1[0-2]|space|Return|Home|End|Insert)$")

# ---------------------------------------------------------------- assinaturas de arquivos
MAGICOS = [
    (b"\x7fELF", "programa Linux compilado (ELF)"),
    (b"MZ", "programa do Windows (EXE/DLL)"),
    (b"\xcf\xfa\xed\xfe", "programa do Mac (Mach-O)"), (b"\xce\xfa\xed\xfe", "programa do Mac (Mach-O)"),
    (b"\xfe\xed\xfa\xce", "programa do Mac (Mach-O)"), (b"\xfe\xed\xfa\xcf", "programa do Mac (Mach-O)"),
    (b"\xca\xfe\xba\xbe", "programa Java/Mac (class/fat)"),
    (b"\x00asm", "WebAssembly"),
    (b"#!", None),   # script: tratado a parte
]
COMPACTADOS = [
    (b"PK\x03\x04", "zip/jar/apk"), (b"\x1f\x8b", "gzip"), (b"BZh", "bzip2"), (b"\xfd7zXZ\x00", "xz"),
    (b"7z\xbc\xaf\x27\x1c", "7z"), (b"Rar!\x1a\x07", "rar"), (b"!<arch>", "pacote .deb/ar"),
    (b"\x28\xb5\x2f\xfd", "zstd"), (b"hsqs", "squashfs/AppImage"), (b"MSCF", "cab"),
    (b"\xed\xab\xee\xdb", "pacote .rpm"),
]
EXT_COMPACTADO = {".zip", ".tar", ".gz", ".tgz", ".bz2", ".xz", ".7z", ".rar", ".deb", ".rpm",
                  ".appimage", ".jar", ".apk", ".zst", ".cab", ".iso", ".img", ".floppamod", ".msi"}
EXT_PROIBIDA = {".exe", ".dll", ".so", ".bin", ".elf", ".com", ".scr", ".bat", ".cmd", ".ps1", ".vbs",
                ".msi", ".run", ".ko", ".o", ".a", ".dylib", ".app", ".lnk", ".pif", ".jar"}
EICAR = b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"

FORMATOS = {   # extensao -> conferencia do conteudo (arquivo "disfarcado" = extensao mentindo)
    ".png": lambda b: b.startswith(b"\x89PNG\r\n\x1a\n"),
    ".jpg": lambda b: b.startswith(b"\xff\xd8\xff"),
    ".jpeg": lambda b: b.startswith(b"\xff\xd8\xff"),
    ".gif": lambda b: b.startswith((b"GIF87a", b"GIF89a")),
    ".webp": lambda b: b.startswith(b"RIFF") and b[8:12] == b"WEBP",
    ".ttf": lambda b: b[:4] in (b"\x00\x01\x00\x00", b"true"),
    ".otf": lambda b: b.startswith(b"OTTO"),
    ".woff": lambda b: b.startswith(b"wOFF"),
    ".woff2": lambda b: b.startswith(b"wOF2"),
    ".ogg": lambda b: b.startswith(b"OggS"), ".oga": lambda b: b.startswith(b"OggS"),
    ".wav": lambda b: b.startswith(b"RIFF") and b[8:12] == b"WAVE",
    ".xpm": lambda b: b.lstrip().startswith(b"/* XPM */"),
}
EXT_TEXTO = {".flp", ".sh", ".py", ".txt", ".md", ".json", ".css", ".scss", ".svg", ".rasi", ".rc",
             ".theme", ".xml", ".desktop", ".csv", ".tsv", ".ini", "", ".conf"}

# ---------------------------------------------------------------- padroes de malware
# (nivel, codigo, explicacao, regex). Valem para qualquer arquivo de texto (scripts, FloopyC, .desktop, css...)
_P = lambda s: re.compile(s, re.IGNORECASE | re.MULTILINE)
PADROES = [
    # virar administrador
    ("bloqueado", "root", "tenta virar administrador (sudo/su/pkexec)",
     _P(r"(^|[\s;&|(`$\"'])(sudo|pkexec|doas|gksudo|kdesu)(\s|$)|(^|[\s;&|(`])su\s+(-|root|-c)")),
    ("bloqueado", "setuid", "tenta dar poder de administrador a um arquivo (setuid)",
     _P(r"chmod\s+([ugoa]*\+[rwx]*s|[0-7]?[4-7][0-7]{3})\b")),
    # baixar e rodar
    ("bloqueado", "baixar-rodar", "baixa algo da internet e roda na hora",
     _P(r"(curl|wget|fetch|lwp-download|aria2c)[^\n|]*\|\s*(sudo\s+)?(ba|z|da|k|c|tc|fi)?sh\b"
        r"|(curl|wget)[^\n|]*\|\s*(python[23]?|perl|ruby|node|php)\b"
        r"|(ba|z)?sh\s+(-c\s+)?[\"']?\$?\(\s*(curl|wget)|(ba|z)?sh\s+<\(\s*(curl|wget)"
        r"|source\s+<\(\s*(curl|wget)")),
    ("bloqueado", "baixar-rodar", "baixa e executa codigo em Python",
     _P(r"(exec|eval)\s*\(\s*(urllib\.request\.)?urlopen|(exec|eval)\s*\([^\n]*requests\.get")),
    # acesso remoto
    ("bloqueado", "shell-reverso", "abre acesso remoto ao computador (shell reverso)",
     _P(r"/dev/(tcp|udp)/|\b(nc|ncat|netcat)\b[^\n]*\s-(e|c)\s|socat[^\n]*exec:|"
        r"mkfifo[^\n]*\b(nc|ncat|netcat)\b|pty\.spawn|telnet[^\n]*\|\s*/bin/(ba)?sh|"
        r"socket\.socket\([^\n]*\)[^\n]*\n?[^\n]*(dup2|subprocess|os\.system)")),
    # destruir dados
    ("bloqueado", "destruir", "apaga ou destroi arquivos do sistema/pessoais",
     _P(r"\brm\s+(-[a-z]*\s+)*(-[a-z]*r[a-z]*f|-[a-z]*f[a-z]*r|--recursive\s+--force|-r\s+-f|-f\s+-r)[a-z]*\s+"
        r"(--no-preserve-root\s+)?[\"']?(/|~|\$home|\$\{home\}|/home|/etc|/usr|/boot|/\*|~/\*)[\"']?(\s|$|;)")),
    ("bloqueado", "destruir", "formata ou escreve direto no disco",
     _P(r"\bmkfs(\.\w+)?\b|\bdd\b[^\n]*\bof=/dev/(sd|nvme|hd|vd|mmcblk)|\bshred\b|\bwipefs\b|"
        r">\s*/dev/(sd|nvme|hd|vd)[a-z]")),
    ("bloqueado", "bomba", "trava o computador (fork bomb)",
     _P(r":\s*\(\s*\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:|while\s+true\s*;\s*do\s+[^\n]*&\s*done|"
        r"os\.fork\(\)[^\n]*\n?[^\n]*while\s+true")),
    # ficar escondido no sistema
    ("bloqueado", "persistencia", "se instala escondido para rodar sempre (bashrc, crontab, servicos)",
     _P(r"(>>?|\btee(\s+-a)?|\bcp\b|\bmv\b|\bln\b|WriteFileSch\s*\(|open\s*\()[^\n]*(\.bashrc|\.bash_profile|\.profile|"
        r"\.zshrc|\.xprofile|\.xsessionrc|\.xinitrc|\.config/autostart|\.config/systemd|crontab|"
        r"/etc/cron|\.local/share/applications/[^\n]*autostart)|\bcrontab\s+(-\s|-e|-l\s*\|)|"
        r"systemctl\s+(--user\s+)?(enable|start|daemon-reload)|\bat\s+now\b")),
    # roubar dados
    ("bloqueado", "roubo", "le senhas, chaves ou dados do navegador",
     _P(r"\.ssh/(id_|authorized_keys|known_hosts)|\.mozilla/firefox|\.config/(google-chrome|chromium|"
        r"BraveSoftware|discord|Signal|Slack)|logins\.json|key[34]\.db|cookies\.sqlite|\.gnupg|"
        r"/etc/(shadow|gshadow|sudoers)|\.local/share/keyrings|\.password-store|wallet\.dat|"
        r"\.electrum|\.bitcoin|\.ethereum|Login\s+Data")),
    ("bloqueado", "keylogger", "espiona o teclado (keylogger)",
     _P(r"\bxinput\s+(test|--test)|\bxev\b|\blogkeys\b|\bshowkey\b|/dev/input/(event|by-)|"
        r"pynput|keyboard\.on_press|xdotool\s+key\s+--repeat")),
    ("bloqueado", "espiao", "grava a tela, a camera ou o microfone escondido",
     _P(r"ffmpeg[^\n]*(x11grab|v4l2|alsa|pulse)|arecord\b|/dev/video\d|\bimport\s+-window\s+root|"
        r"scrot[^\n]*-z|xwd\s+-root")),
    ("bloqueado", "minerador", "usa o computador para minerar criptomoeda",
     _P(r"xmrig|stratum\+(tcp|ssl)|\bminerd\b|cpuminer|cryptonight|randomx|nicehash|"
        r"moneroocean|minexmr|supportxmr|2miners|nanopool")),
    ("bloqueado", "ofuscado", "esconde codigo (base64/hex decodificado e executado)",
     _P(r"base64\s+(-d|--decode|-D)[^\n]*\|\s*(ba|z)?sh|base64\s+(-d|--decode)[^\n]*\|\s*(python|perl)|"
        r"(exec|eval)\s*\(\s*(base64\.)?b(64|16|32|85)decode|(exec|eval)\s*\([^\n]*(codecs\.decode|"
        r"bytes\.fromhex|zlib\.decompress|marshal\.loads|\.decode\(\s*['\"]rot)|"
        r"eval\s+\"?\$\(\s*(echo|printf)[^\n]*(base64|xxd|\\x[0-9a-f]{2})|"
        r"printf\s+[\"'](\\x[0-9a-f]{2}){8,}[^\n]*\|\s*(ba)?sh|xxd\s+-r[^\n]*\|\s*(ba)?sh")),
    ("bloqueado", "preload", "se injeta em outros programas (LD_PRELOAD)",
     _P(r"LD_PRELOAD|/etc/ld\.so\.preload|LD_LIBRARY_PATH\s*=")),
    ("bloqueado", "desligar-protecao", "desliga o firewall ou a protecao do sistema",
     _P(r"floppa-central-aplicar\s+firewall\s+off|\bnft\s+(flush|delete)|iptables\s+-(F|X|P)|"
        r"\bufw\s+disable|setenforce\s+0|systemctl[^\n]*(stop|disable|mask)[^\n]*(floppa|firewall|apparmor)")),
    ("bloqueado", "sistema", "tenta mudar arquivos do sistema (/etc, /usr, /boot)",
     _P(r"(>>?|\btee(\s+-a)?)\s*[\"']?/(etc|usr|boot|bin|sbin|lib|lib64|root|opt|sys|proc)/|"
        r"\b(cp|mv|ln|install|rsync)\b[^\n;|&]*\s[\"']?/(etc|usr|boot|bin|sbin|lib|lib64|root|opt)/[^\s;|&\"']*[\"']?\s*($|[;|&])|"
        r"\b(chmod|chown|chattr|rm|unlink)\b[^\n;|&]*\s[\"']?/(etc|usr|boot|bin|sbin|lib|lib64|root|opt)/|"
        r"WriteFileSch\s*\(\s*\"/|"
        r"open\s*\(\s*['\"]/(etc|usr|boot|bin|sbin|lib|lib64|root|opt)/[^'\"]*['\"]\s*,\s*['\"][wax+]")),
    ("bloqueado", "disfarce", "FloopyC mandando rodar um arquivo que nao e .flp como se fosse codigo",
     _P(r"RunFlp\s*\(\s*\"(?![^\"]*\.flp\")[^\"]*\"")),
    ("atencao", "comando", "FloopyC roda um arquivo escolhido na hora (nao da para saber qual)",
     _P(r"RunFlp\s*\(\s*[^\"\s)]")),
    ("bloqueado", "historico", "apaga rastros (historico, logs)",
     _P(r"history\s+-c|unset\s+HISTFILE|HISTFILE\s*=\s*/dev/null|>\s*~?/?\.?bash_history|"
        r"journalctl\s+--vacuum|rm\s+[^\n]*\.bash_history")),
    ("bloqueado", "kill-sistema", "fecha programas do sistema ou desliga o computador sem avisar",
     _P(r"\b(killall|pkill)\s+(-9\s+)?(xfce4-panel|xfwm4|xfdesktop|lightdm|systemd|NetworkManager|"
        r"floppa|earlyoom|pulseaudio|pipewire)|kill\s+-9\s+(-1|1)\b|\b(shutdown|poweroff|reboot|halt)"
        r"(\s+(-h|now|-r|-P))|systemctl\s+(poweroff|reboot|halt)")),
    ("bloqueado", "codigo-dinamico", "monta codigo na hora e roda (nao da para conferir antes)",
     _P(r"(^|[^\w.])(exec|eval|compile|__import__|execfile)\s*\(|\bimportlib\.import_module\s*\(|"
        r"(^|[\s;&|(])eval\s|(ba|z|da)?sh\s+-c\s+[\"']?\$|\bsource\s+[\"']?\$|(^|[\s;&|])\.\s+[\"']?\$|"
        r"WriteFileSch\s*\([^\n)]*\.flp")),
    # avisos (o usuario precisa confirmar)
    ("atencao", "internet", "acessa a internet",
     _P(r"\b(curl|wget|aria2c|urllib|requests\.(get|post)|http\.client|socket\.socket|nc\s+[a-z0-9.]+\s+\d+)|"
        r"https?://(?!www\.w3\.org/)")),
    ("atencao", "comando", "roda comandos do sistema",
     _P(r"os\.(system|popen|exec[lv]p?e?)\s*\(|subprocess\.|shell\s*=\s*True|\beval\s+\"\$|`[^`\n]{3,}`")),
    ("atencao", "apagar", "apaga arquivos",
     _P(r"\brm\s+-[a-z]*r|shutil\.rmtree|os\.(remove|unlink|rmdir)\s*\(")),
    ("atencao", "arquivos", "le ou grava arquivos fora da pasta do mod",
     _P(r"(ReadFileBin|WriteFileSch|ListFilesBin)\s*\(\s*\"(~|/)|open\s*\(\s*['\"](~|/home)|"
        r"os\.path\.expanduser\(\s*['\"]~['\"]?\s*\)?\s*\)?|\$HOME/(?!\.local/share/floppa-mods)")),
    ("atencao", "ctypes", "carrega bibliotecas nativas", _P(r"\bctypes\b|\bcffi\b|dlopen")),
]

# blobs escondidos dentro de scripts (base64/hex muito longos)
BLOB_B64 = re.compile(rb"[A-Za-z0-9+/]{400,}={0,2}")
BLOB_HEX = re.compile(rb"(\\x[0-9a-fA-F]{2}){100,}|\b[0-9a-fA-F]{600,}\b")
SVG_PERIGO = re.compile(r"<\s*script|\bon[a-z]+\s*=|javascript\s*:|<\s*foreignObject|<\s*iframe|"
                        r"<\s*embed|<\s*object|<!ENTITY|<!DOCTYPE[^>]*\[", re.IGNORECASE)
SVG_EXTERNO = re.compile(r"(xlink:)?href\s*=\s*[\"']\s*(https?:|file:|//)", re.IGNORECASE)
CSS_EXTERNO = re.compile(r"url\(\s*[\"']?\s*(https?:|file:|//)|@import\s+[\"']?\s*(url\()?\s*[\"']?(https?:|//)",
                         re.IGNORECASE)
INVISIVEIS = re.compile("[​-‏‪-‮⁦-⁩﻿­]")
NOME_SEGURO = re.compile(r"^[A-Za-z0-9._@+ ()\[\]-]+$")
ID_MOD = re.compile(r"^[a-z0-9](?:[a-z0-9-]{1,38}[a-z0-9])$")
VERSAO = re.compile(r"^\d{1,4}(\.\d{1,4}){0,3}$")
TEXTO_CURTO = re.compile(r"^[^\x00-\x1f\x7f]{1,300}$")


class Relatorio:
    def __init__(self):
        self.achados = []
        self.manifesto = None
        self.sha256 = None
        self.arquivos = 0
        self.inicio = time.monotonic()
        self.clamav = "nao usado"

    def add(self, nivel, codigo, arquivo, msg):
        chave = (nivel, codigo, arquivo, msg)
        if chave not in [(a["nivel"], a["codigo"], a["arquivo"], a["mensagem"]) for a in self.achados]:
            self.achados.append({"nivel": nivel, "codigo": codigo, "arquivo": arquivo, "mensagem": msg})

    @property
    def veredito(self):
        pior = max([NIVEIS[a["nivel"]] for a in self.achados] or [0])
        return {0: "limpo", 1: "atencao", 2: "bloqueado"}[pior]

    def como_dict(self):
        return {"veredito": self.veredito, "achados": self.achados, "manifesto": self.manifesto,
                "sha256": self.sha256, "arquivos": self.arquivos, "clamav": self.clamav,
                "versao_escudo": VERSAO_ESCUDO, "duracao": round(time.monotonic() - self.inicio, 2),
                "data": time.strftime("%Y-%m-%d %H:%M:%S")}


class _Tempo(Exception):
    pass


# ---------------------------------------------------------------- nomes de arquivos
def checar_nome(nome):
    """Devolve (ok, motivo) para um caminho dentro do pacote."""
    if not nome or len(nome) > LIMITE_CAMINHO:
        return False, "caminho vazio ou comprido demais"
    if "\x00" in nome or "\\" in nome:
        return False, "caractere proibido no nome"
    if any(ord(c) < 32 or ord(c) == 127 for c in nome):
        return False, "caractere de controle no nome"
    if INVISIVEIS.search(nome):
        return False, "caractere invisivel no nome (pode esconder a extensao verdadeira)"
    if nome.startswith("/") or re.match(r"^[A-Za-z]:", nome):
        return False, "caminho absoluto"
    partes = [p for p in nome.split("/") if p not in ("", ".")]
    if not partes:
        return False, "caminho vazio"
    for p in partes:
        if p == "..":
            return False, "tenta sair da pasta do mod ('..')"
        if len(p) > LIMITE_NOME:
            return False, "nome comprido demais"
        if p.startswith("-"):
            return False, "nome comecando com '-'"
        if p.startswith("~"):
            return False, "nome comecando com '~'"
    if unicodedata.normalize("NFC", nome) != nome:
        return False, "nome com acentos em forma estranha (normalizacao)"
    return True, ""


def normalizar(nome):
    return "/".join(p for p in nome.split("/") if p not in ("", "."))


# ---------------------------------------------------------------- leitura do pacote
def _ler_membros(caminho, rel):
    """Abre o pacote e confere a estrutura. Devolve {nome: bytes} so com arquivos comuns (ou None)."""
    try:
        tam = os.path.getsize(caminho)
    except OSError as e:
        rel.add("bloqueado", "pacote", "", "nao consegui ler o pacote: %s" % e)
        return None
    if tam == 0:
        rel.add("bloqueado", "pacote", "", "pacote vazio")
        return None
    if tam > LIMITE_PACOTE:
        rel.add("bloqueado", "tamanho", "", "pacote grande demais (%d MB, o maximo e %d MB)"
                % (tam // 1048576, LIMITE_PACOTE // 1048576))
        return None
    h = hashlib.sha256()
    with open(caminho, "rb") as f:
        for bloco in iter(lambda: f.read(1 << 20), b""):
            h.update(bloco)
    rel.sha256 = h.hexdigest()

    arquivos, vistos, vistos_min = {}, set(), set()
    total = 0
    try:
        tf = tarfile.open(caminho, mode="r:*")
    except (tarfile.TarError, OSError, EOFError, ValueError) as e:
        rel.add("bloqueado", "pacote", "", "nao e um pacote .floppamod valido (%s)" % type(e).__name__)
        return None
    try:
        with tf:
            n = 0
            for m in tf:  # iteracao preguicosa: para no limite sem ler tudo
                n += 1
                if n > LIMITE_ARQUIVOS:
                    rel.add("bloqueado", "quantidade", "", "arquivos demais (mais de %d)" % LIMITE_ARQUIVOS)
                    return None
                if time.monotonic() - rel.inicio > LIMITE_TEMPO:
                    raise _Tempo()
                nome = m.name
                ok, motivo = checar_nome(nome)
                if not ok:
                    rel.add("bloqueado", "nome", nome[:200], motivo)
                    continue
                nome = normalizar(nome)
                if m.isdir():
                    if m.mode & (stat.S_ISUID | stat.S_ISGID):
                        rel.add("bloqueado", "setuid", nome, "pasta com permissao especial (setuid/setgid)")
                    continue
                if m.issym() or m.islnk():
                    rel.add("bloqueado", "link", nome, "atalho/link para '%s' (pode apontar para fora do mod)"
                            % m.linkname[:120])
                    continue
                if not m.isreg():
                    rel.add("bloqueado", "tipo", nome, "tipo de arquivo proibido (dispositivo, fifo ou especial)")
                    continue
                if m.mode & (stat.S_ISUID | stat.S_ISGID | stat.S_ISVTX):
                    rel.add("bloqueado", "setuid", nome, "arquivo com permissao de administrador (setuid/setgid)")
                if nome in vistos:
                    rel.add("bloqueado", "repetido", nome, "o mesmo arquivo aparece duas vezes (pode trocar um pelo outro)")
                    continue
                if nome.lower() in vistos_min:
                    rel.add("atencao", "repetido", nome, "dois arquivos com o mesmo nome (so muda maiuscula/minuscula)")
                vistos.add(nome)
                vistos_min.add(nome.lower())
                if m.size > LIMITE_ARQUIVO:
                    rel.add("bloqueado", "tamanho", nome, "arquivo grande demais (%d MB)" % (m.size // 1048576))
                    return None
                total += m.size
                if total > LIMITE_TOTAL:
                    rel.add("bloqueado", "bomba-compressao", "", "o mod descomprimido passa de %d MB"
                            % (LIMITE_TOTAL // 1048576))
                    return None
                if total > 10 * 1048576 and total > tam * LIMITE_PROPORCAO:
                    rel.add("bloqueado", "bomba-compressao", "",
                            "compressao exagerada (%dx): parece uma bomba de compressao" % (total // max(tam, 1)))
                    return None
                f = tf.extractfile(m)
                dados = f.read(m.size + 1) if f else b""
                if len(dados) != m.size:
                    rel.add("bloqueado", "pacote", nome, "arquivo corrompido ou cortado")
                    return None
                arquivos[nome] = dados
    except _Tempo:
        raise
    except (tarfile.TarError, OSError, EOFError, ValueError, zlib_erro()) as e:
        rel.add("bloqueado", "pacote", "", "pacote corrompido (%s)" % type(e).__name__)
        return None
    rel.arquivos = len(arquivos)
    return arquivos


def zlib_erro():
    import zlib
    return zlib.error


# ---------------------------------------------------------------- mod.json
def _str(d, k, padrao=None):
    v = d.get(k, padrao)
    return v if isinstance(v, str) else None


def checar_valor(tipo, regra, valor):
    if tipo == "bool":
        return isinstance(valor, bool)
    if tipo in ("int", "uint"):
        if isinstance(valor, bool) or not isinstance(valor, int):
            return False
        return regra is None or regra[0] <= valor <= regra[1]
    if tipo == "string":
        return isinstance(valor, str) and "\n" not in valor and (regra is None or bool(regra.match(valor)))
    return False


def checar_destino(para, de, rel):
    """'fundos/x.png' -> (raiz, resto) ou None."""
    if not isinstance(para, str):
        rel.add("bloqueado", "manifesto", str(de), "destino invalido")
        return None
    ok, motivo = checar_nome(para)
    if not ok:
        rel.add("bloqueado", "destino", para, "destino perigoso: %s" % motivo)
        return None
    para = normalizar(para)
    raiz, _, resto = para.partition("/")
    if raiz not in DESTINOS or not resto:
        rel.add("bloqueado", "destino", para, "o mod so pode instalar em: %s" % ", ".join(sorted(DESTINOS)))
        return None
    ext = os.path.splitext(resto)[1].lower()
    permitidas = DESTINOS[raiz]
    if raiz in ("temas", "icones", "cursores"):
        permitidas = EXT_TEMA
    elif raiz == "programas":
        permitidas = EXT_PROGRAMA
    if permitidas is not None and ext not in permitidas:
        rel.add("bloqueado", "destino", para, "tipo de arquivo '%s' nao e aceito em '%s'" % (ext or "sem extensao", raiz))
        return None
    return raiz, resto


def checar_manifesto(arquivos, rel):
    bruto = arquivos.get("mod.json")
    if bruto is None:
        rel.add("bloqueado", "manifesto", "mod.json", "falta o mod.json")
        return None
    if len(bruto) > LIMITE_MANIFESTO:
        rel.add("bloqueado", "manifesto", "mod.json", "mod.json grande demais")
        return None
    try:
        m = json.loads(bruto.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        rel.add("bloqueado", "manifesto", "mod.json", "mod.json nao e um JSON valido")
        return None
    if not isinstance(m, dict):
        rel.add("bloqueado", "manifesto", "mod.json", "mod.json precisa ser um objeto {}")
        return None

    def textos(x):   # todos os textos do JSON ja decodificados (pega coisa escondida com \\u e \\\\)
        if isinstance(x, str):
            yield x
        elif isinstance(x, dict):
            for k, v in x.items():
                yield str(k)
                yield from textos(v)
        elif isinstance(x, list):
            for v in x:
                yield from textos(v)
    eicar = EICAR.decode("ascii")
    if any(eicar in t for t in textos(m)):
        rel.add("bloqueado", "virus", "mod.json", "virus de teste EICAR escondido no mod.json")

    ident = _str(m, "id")
    if not ident or not ID_MOD.match(ident):
        rel.add("bloqueado", "manifesto", "mod.json", "id invalido (use 3 a 40 letras minusculas, numeros e '-')")
        return None
    for campo in ("nome", "autor", "descricao"):
        v = _str(m, campo)
        if not v or not TEXTO_CURTO.match(v) or INVISIVEIS.search(v):
            rel.add("bloqueado", "manifesto", "mod.json", "campo '%s' faltando ou invalido" % campo)
    v = _str(m, "versao")
    if not v or not VERSAO.match(v):
        rel.add("bloqueado", "manifesto", "mod.json", "versao invalida (ex: 1.0)")
    if m.get("tipo") not in TIPOS:
        rel.add("bloqueado", "manifesto", "mod.json", "tipo invalido (use: %s)" % ", ".join(sorted(TIPOS)))
    conhecidos = {"id", "nome", "autor", "descricao", "versao", "tipo", "instalar", "configuracoes",
                  "fundo", "visual", "atalhos", "aplicativos", "iniciar_ao_entrar", "dock", "site",
                  "licenca", "floppa_minimo"}
    for k in m:
        if k not in conhecidos:
            rel.add("atencao", "manifesto", "mod.json", "campo desconhecido '%s' (ignorado)" % str(k)[:40])

    # arquivos -> destinos
    destinos = {}
    inst = m.get("instalar", [])
    if not isinstance(inst, list) or len(inst) > LIMITE_ARQUIVOS:
        rel.add("bloqueado", "manifesto", "mod.json", "'instalar' precisa ser uma lista")
        inst = []
    for item in inst:
        if not isinstance(item, dict) or not isinstance(item.get("de"), str):
            rel.add("bloqueado", "manifesto", "mod.json", "item de 'instalar' invalido")
            continue
        de = item["de"]
        ok, motivo = checar_nome(de)
        if not ok:
            rel.add("bloqueado", "manifesto", de[:200], motivo)
            continue
        de = normalizar(de)
        if de not in arquivos:
            rel.add("bloqueado", "manifesto", de, "o mod.json cita um arquivo que nao existe no pacote")
            continue
        if de == "mod.json":
            rel.add("bloqueado", "manifesto", de, "o mod.json nao pode ser instalado")
            continue
        d = checar_destino(item.get("para"), de, rel)
        if d:
            final = "/".join(d)
            if final in destinos:
                rel.add("bloqueado", "manifesto", final, "dois arquivos vao para o mesmo lugar")
            destinos[final] = de

    # configuracoes do XFCE (so lista branca)
    confs = m.get("configuracoes", [])
    if not isinstance(confs, list) or len(confs) > 100:
        rel.add("bloqueado", "manifesto", "mod.json", "'configuracoes' precisa ser uma lista (ate 100)")
        confs = []
    for c in confs:
        if not isinstance(c, dict):
            rel.add("bloqueado", "configuracao", "mod.json", "configuracao invalida")
            continue
        canal, prop = c.get("canal"), c.get("prop")
        regra = LISTA_BRANCA.get(canal, {}).get(prop) if isinstance(canal, str) and isinstance(prop, str) else None
        if regra is None:
            rel.add("bloqueado", "configuracao", "mod.json",
                    "configuracao fora da lista permitida: %s %s" % (str(canal)[:40], str(prop)[:80]))
            continue
        if c.get("tipo", regra[0]) != regra[0] or not checar_valor(regra[0], regra[1], c.get("valor")):
            rel.add("bloqueado", "configuracao", "mod.json", "valor invalido para %s %s" % (canal, prop))

    if "visual" in m and m["visual"] not in VISUAIS:
        rel.add("bloqueado", "manifesto", "mod.json", "'visual' invalido (use: %s)" % ", ".join(sorted(VISUAIS)))
    if "dock" in m and not isinstance(m["dock"], bool):
        rel.add("bloqueado", "manifesto", "mod.json", "'dock' precisa ser true ou false")
    if "fundo" in m:
        f = m["fundo"]
        if not isinstance(f, str) or normalizar(f) not in destinos or not normalizar(f).startswith("fundos/"):
            rel.add("bloqueado", "manifesto", "mod.json", "'fundo' precisa ser um arquivo instalado em fundos/")

    def programa(caminho, onde):
        if not isinstance(caminho, str):
            rel.add("bloqueado", "manifesto", "mod.json", "%s: programa invalido" % onde)
            return
        p = normalizar(caminho)
        ext = os.path.splitext(p)[1].lower()
        if not p.startswith("programas/") or p not in destinos:
            rel.add("bloqueado", "manifesto", "mod.json", "%s: o programa precisa ser um arquivo do mod em programas/" % onde)
        elif ext not in EXECUTAVEIS:
            rel.add("bloqueado", "manifesto", "mod.json", "%s: so roda .flp, .sh ou .py" % onde)
        elif ext in (".sh", ".py"):
            rel.add("atencao", "script", p, "%s roda um script %s (confira os avisos abaixo)" % (onde, ext))

    apps = m.get("aplicativos", [])
    if not isinstance(apps, list) or len(apps) > 20:
        rel.add("bloqueado", "manifesto", "mod.json", "'aplicativos' precisa ser uma lista (ate 20)")
        apps = []
    for a in apps:
        if not isinstance(a, dict) or not isinstance(a.get("nome"), str) or not TEXTO_CURTO.match(a["nome"]):
            rel.add("bloqueado", "manifesto", "mod.json", "aplicativo sem nome valido")
            continue
        programa(a.get("executar"), "aplicativo '%s'" % a["nome"][:40])
        if "icone" in a and (not isinstance(a["icone"], str) or normalizar(a["icone"]) not in destinos):
            rel.add("bloqueado", "manifesto", "mod.json", "icone do aplicativo precisa ser um arquivo do mod")
        if "terminal" in a and not isinstance(a["terminal"], bool):
            rel.add("bloqueado", "manifesto", "mod.json", "'terminal' precisa ser true ou false")

    atalhos = m.get("atalhos", [])
    if not isinstance(atalhos, list) or len(atalhos) > 20:
        rel.add("bloqueado", "manifesto", "mod.json", "'atalhos' precisa ser uma lista (ate 20)")
        atalhos = []
    for a in atalhos:
        if not isinstance(a, dict) or not isinstance(a.get("tecla"), str) or not TECLA.match(a["tecla"]):
            rel.add("bloqueado", "manifesto", "mod.json", "atalho com tecla invalida (ex: <Super>F5)")
            continue
        programa(a.get("executar"), "atalho %s" % a["tecla"])
        if "terminal" in a and not isinstance(a["terminal"], bool):
            rel.add("bloqueado", "manifesto", "mod.json", "'terminal' do atalho precisa ser true ou false")

    if "iniciar_ao_entrar" in m:
        programa(m["iniciar_ao_entrar"], "abrir ao entrar")
        rel.add("atencao", "inicializacao", "mod.json", "o mod abre um programa toda vez que voce entra no sistema")

    nao_usados = [n for n in arquivos if n != "mod.json" and n not in destinos.values()]
    if nao_usados:
        rel.add("info", "sobra", "", "%d arquivo(s) do pacote nao sao instalados" % len(nao_usados))
    m["_destinos"] = destinos
    return m


# ---------------------------------------------------------------- conteudo
def eh_texto(dados):
    amostra = dados[:8192]
    if b"\x00" in amostra:
        return False
    try:
        amostra.decode("utf-8")
        return True
    except UnicodeDecodeError as e:
        return e.start > len(amostra) - 4   # cortou no meio de um caractere


def _eh_pe(dados):
    """MZ + cabecalho PE de verdade (um texto que comeca com 'MZ' nao e programa)."""
    if len(dados) < 64:
        return False
    off = int.from_bytes(dados[0x3c:0x40], "little")
    return 0 < off < len(dados) - 4 and dados[off:off + 4] == b"PE\x00\x00"


def _sem_comentarios(texto, ext):
    """Apaga as linhas que sao so comentario (nao rodam), mantendo a numeracao das linhas."""
    if ext in (".sh", ".py") or texto.startswith("#!"):
        marca = "#"
    elif ext == ".flp":
        marca = "--"
    else:
        return texto
    linhas = texto.split("\n")
    for i, l in enumerate(linhas):
        if l.lstrip().startswith(marca) and not (i == 0 and l.startswith("#!")):
            linhas[i] = ""
    return "\n".join(linhas)


_PY_TRUQUES = re.compile(
    r"\bgetattr\s*\(\s*(os|subprocess|sys|builtins|__builtins__|socket|shutil|pty)\b|__builtins__|"
    r"\bglobals\s*\(\s*\)\s*\[|\bvars\s*\(\s*(os|builtins|__builtins__)|\b(pickle|marshal|dill|shelve)\.loads?\s*\(|"
    r"\bsys\.modules\s*\[|\b__class__\b.*\b__subclasses__\b|\b__subclasses__\s*\(", re.MULTILINE)
_PY_IMPORT_PERIGO = re.compile(r"^\s*(from\s+(os|subprocess|pty|socket|ctypes|shutil)\s+import|"
                               r"import\s+[^\n]*\b(os|subprocess|pty|socket|ctypes|shutil)\b)", re.MULTILINE)
_SEPARA = re.compile(r"\|\||&&|[;&|(){}]|\$\(|`")
# palavras que vem ANTES do comando de verdade (if x / do x / exec x / env x ...): pula para a proxima
_PREFIXOS = {"then", "do", "else", "elif", "if", "while", "until", "time", "exec", "command", "builtin",
             "nohup", "env", "xargs", "setsid", "!", "nice", "timeout", "stdbuf", "ionice"}
_ATRIB = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\[[^\]]*\])?\+?=")


def _analisar_shell(texto):
    """Truques de shell que escondem o comando de verdade: s\\udo, "su"do, $'\\x73'udo, $CMD args, ${!x}."""
    achados = []
    for i, linha in enumerate(texto.split("\n"), 1):
        l = linha.strip()
        if not l or l.startswith("#"):
            continue
        if re.search(r"\$'[^']*\\(x[0-9a-fA-F]|[0-7]{3}|u[0-9a-fA-F]{4})", l):
            achados.append((i, "ofuscado", "texto escondido com $'\\x..' (codigo disfarcado)"))
        if "${!" in l:
            achados.append((i, "codigo-dinamico", "nome de variavel montado na hora (${!...})"))
        for pedaco in _SEPARA.split(l):
            palavras = pedaco.strip().split()
            while palavras and (_ATRIB.match(palavras[0]) or palavras[0] in _PREFIXOS
                                or re.match(r"^-[A-Za-z0-9=]*$|^\d+$", palavras[0])):
                palavras.pop(0)   # VAR=valor, if/do/exec/env/timeout e as opcoes/numeros deles
            if not palavras:
                continue
            cmd = palavras[0]
            if cmd.startswith(("$", '"$', "'$", "${")):
                achados.append((i, "codigo-dinamico", "roda um comando guardado numa variavel (%s)" % cmd[:30]))
            elif re.search(r"[A-Za-z0-9_./-](\\.|''|\"\"|'[^']*'|\"[^\"]*\")[A-Za-z0-9_.-]", cmd) or \
                    re.match(r"^(\\[A-Za-z]|'[A-Za-z]+'[A-Za-z]|\"[A-Za-z]+\"[A-Za-z])", cmd):
                achados.append((i, "ofuscado", "nome de comando disfarcado com aspas/barra (%s)" % cmd[:30]))
    return achados


def checar_conteudo(nome, dados, rel, destino=None):
    ext = os.path.splitext(nome)[1].lower()
    base = os.path.basename(nome).lower()

    if EICAR in dados:
        rel.add("bloqueado", "virus", nome, "virus de teste EICAR encontrado")
    if ext in EXT_PROIBIDA or base.endswith(".appimage"):
        rel.add("bloqueado", "executavel", nome, "tipo de arquivo proibido em mods (%s)" % (ext or base))
    if ext in EXT_COMPACTADO:
        rel.add("bloqueado", "compactado", nome, "pacote dentro do pacote (nao da para conferir o que tem dentro)")
    for magico, oque in MAGICOS:
        if oque and dados.startswith(magico):
            if magico == b"MZ" and not _eh_pe(dados):
                continue
            rel.add("bloqueado", "executavel", nome, "%s escondido no mod" % oque)
    for magico, oque in COMPACTADOS:
        if dados.startswith(magico) and ext not in (".svg",):
            rel.add("bloqueado", "compactado", nome, "arquivo compactado (%s) escondido no mod" % oque)
    # duas extensoes (foto.png.sh) ou extensao que nao bate com o conteudo
    partes = base.split(".")
    if len(partes) >= 3 and "." + partes[-2] in FORMATOS and ext in EXECUTAVEIS:
        rel.add("bloqueado", "disfarce", nome, "nome disfarcado (parece imagem mas e programa)")
    if ext in FORMATOS and not FORMATOS[ext](dados):
        rel.add("bloqueado", "disfarce", nome, "o arquivo diz ser %s mas o conteudo e outra coisa" % ext)
    if ext in FORMATOS:
        return  # imagem/fonte/som de verdade: nao roda, nao precisa procurar codigo
    if not eh_texto(dados):
        if ext in EXT_TEXTO or ext not in FORMATOS:
            rel.add("bloqueado", "binario", nome, "arquivo binario desconhecido (nao da para conferir)")
        return

    texto = dados[:LIMITE_TEXTO_ANALISE].decode("utf-8", errors="replace")
    if ext in (".sh", ".py") or texto.startswith("#!"):
        rel.add("atencao", "script", nome, "o mod traz um script (%s) que pode ser rodado: confira os outros avisos"
                % (ext or "sem extensao"))
    if INVISIVEIS.search(texto) and ext in EXECUTAVEIS:
        rel.add("bloqueado", "ofuscado", nome, "caracteres invisiveis no codigo (podem esconder comandos)")
    eh_codigo = ext in EXECUTAVEIS or texto.startswith("#!") or ext == ".desktop"
    doc = ext in (".md", ".txt", ".json") and not texto.startswith("#!")
    analisado = _sem_comentarios(texto, ext)
    for nivel, codigo, msg, rx in PADROES:
        if nivel == "atencao" and not eh_codigo:
            continue
        if doc and nivel == "bloqueado":   # documento nao roda: so avisa
            nivel, msg = "atencao", "o texto de um documento fala de: " + msg
        achou = rx.search(analisado)
        if achou:
            linha = texto.count("\n", 0, achou.start()) + 1
            rel.add(nivel, codigo, "%s:%d" % (nome, linha), msg)
    e_shell = ext == ".sh" or re.match(r"^#!\s*(/usr)?/bin/(env\s+)?(ba|da|z|k)?sh\b", texto) is not None
    e_python = ext == ".py" or re.match(r"^#!\s*(/usr)?/bin/(env\s+)?python", texto) is not None
    if e_shell:
        for linha, codigo, msg in _analisar_shell(analisado):
            rel.add("bloqueado", codigo, "%s:%d" % (nome, linha), msg)
    if e_python:
        t = _PY_TRUQUES.search(analisado)
        if t:
            rel.add("bloqueado", "codigo-dinamico", "%s:%d" % (nome, analisado.count("\n", 0, t.start()) + 1),
                    "acessa funcoes do Python por caminho escondido (getattr/__builtins__/pickle)")
        if _PY_IMPORT_PERIGO.search(analisado):
            rel.add("atencao", "comando", nome, "usa modulos que mexem no sistema (os/subprocess/socket)")
    if eh_codigo:
        if BLOB_B64.search(dados[:LIMITE_TEXTO_ANALISE]) or BLOB_HEX.search(dados[:LIMITE_TEXTO_ANALISE]):
            rel.add("bloqueado", "ofuscado", nome, "bloco gigante de codigo escondido (base64/hex) num script")
        if texto.startswith("#!"):
            prim = texto.split("\n", 1)[0]
            if not re.match(r"^#!\s*(/usr)?/bin/(env\s+)?(ba|da)?sh\b|^#!\s*(/usr)?/bin/(env\s+)?python3?\b|"
                            r"^#!\s*(/usr)?/(local/)?bin/(env\s+)?floopyc\b", prim):
                rel.add("atencao", "interpretador", nome, "script para um interpretador incomum: %s" % prim[:60])
        if ext == ".desktop" or "[desktop entry]" in texto[:200].lower():
            rel.add("bloqueado", "desktop", nome, "mods nao trazem .desktop prontos (o Floppa Mods cria os atalhos)")
    if ext == ".svg" or "<svg" in texto[:2000].lower():
        if SVG_PERIGO.search(texto):
            rel.add("bloqueado", "svg", nome, "imagem SVG com codigo (script/eventos/entidades)")
        if SVG_EXTERNO.search(texto):
            rel.add("atencao", "svg", nome, "imagem SVG que busca coisas na internet")
    if ext in (".css", ".scss", ".rasi") and CSS_EXTERNO.search(texto):
        rel.add("atencao", "css", nome, "tema que busca arquivos na internet")


def checar_lista_negra(arquivos, rel, lista_negra):
    if not lista_negra:
        return
    if rel.sha256 in lista_negra:
        rel.add("bloqueado", "lista-negra", "", "este mod foi denunciado e esta na lista negra do Floppa")
    for nome, dados in arquivos.items():
        if hashlib.sha256(dados).hexdigest() in lista_negra:
            rel.add("bloqueado", "lista-negra", nome, "arquivo denunciado (lista negra do Floppa)")


def ler_lista_negra(texto):
    """'sha256|motivo' por linha -> {sha256}"""
    s = set()
    for linha in (texto or "").splitlines():
        c = linha.strip().split("|")[0].strip().lower()
        if re.match(r"^[0-9a-f]{64}$", c):
            s.add(c)
    return s


def _clamav(arquivos, rel, usar):
    exe = shutil.which("clamscan") if usar else None
    if not exe:
        rel.clamav = "nao instalado" if usar else "nao usado"
        return
    pasta = tempfile.mkdtemp(prefix="floppa-escudo-")
    try:
        os.chmod(pasta, 0o700)
        for i, (nome, dados) in enumerate(arquivos.items()):
            with open(os.path.join(pasta, "%05d" % i), "wb") as f:   # nomes neutros: nada de caminho do mod
                f.write(dados)
        resta = max(60, int(LIMITE_TEMPO - (time.monotonic() - rel.inicio)))
        try:
            p = subprocess.run([exe, "--no-summary", "--infected", "-r", pasta], capture_output=True,
                               text=True, timeout=resta)
        except subprocess.TimeoutExpired:
            raise _Tempo()
        nomes = list(arquivos)
        if p.returncode == 1:
            for linha in p.stdout.splitlines():
                m = re.match(r"^.*/(\d{5}): (.*) FOUND$", linha)
                arq = nomes[int(m.group(1))] if m and int(m.group(1)) < len(nomes) else ""
                rel.add("bloqueado", "virus", arq, "ClamAV: %s" % (m.group(2) if m else linha[:120]))
            rel.clamav = "achou virus"
        elif p.returncode == 0:
            rel.clamav = "limpo"
        else:
            rel.clamav = "erro (%d)" % p.returncode
            rel.add("info", "clamav", "", "o ClamAV nao conseguiu conferir (base de virus desatualizada?)")
    finally:
        shutil.rmtree(pasta, ignore_errors=True)


# ---------------------------------------------------------------- tudo junto
def verificar(caminho, lista_negra=None, usar_clamav=True, limite_tempo=None):
    """Confere um .floppamod. Nunca levanta excecao: sempre devolve o relatorio (dict)."""
    global LIMITE_TEMPO
    antigo = LIMITE_TEMPO
    if limite_tempo is not None:
        LIMITE_TEMPO = limite_tempo
    rel = Relatorio()
    try:
        arquivos = _ler_membros(caminho, rel)
        if arquivos is not None:
            m = checar_manifesto(arquivos, rel)
            destinos = (m or {}).get("_destinos", {})
            origem_para_destino = {v: k for k, v in destinos.items()}
            for nome, dados in arquivos.items():
                if time.monotonic() - rel.inicio > LIMITE_TEMPO:
                    raise _Tempo()
                if nome == "mod.json":
                    if EICAR in dados:
                        rel.add("bloqueado", "virus", nome, "virus de teste EICAR encontrado")
                    continue
                checar_conteudo(nome, dados, rel, origem_para_destino.get(nome))
            checar_lista_negra(arquivos, rel, lista_negra)
            if rel.veredito != "bloqueado":
                _clamav(arquivos, rel, usar_clamav)
            if m:
                m.pop("_destinos", None)
                rel.manifesto = {k: m[k] for k in ("id", "nome", "versao", "autor", "tipo", "descricao") if k in m}
    except _Tempo:
        rel.add("bloqueado", "tempo", "", "a checagem passou de %d minutos: mod bloqueado por seguranca"
                % (LIMITE_TEMPO // 60))
    except MemoryError:
        rel.add("bloqueado", "memoria", "", "o mod e pesado demais para conferir")
    except Exception as e:  # o escudo nunca pode deixar passar por causa de um erro dele
        rel.add("bloqueado", "erro", "", "erro na checagem (%s): bloqueado por seguranca" % type(e).__name__)
    finally:
        LIMITE_TEMPO = antigo
    return rel.como_dict()


def ler_pacote(caminho):
    """Depois de aprovado: le o pacote de novo (mesmas regras) e devolve {nome: bytes} e o mod.json."""
    rel = Relatorio()
    arquivos = _ler_membros(caminho, rel)
    if arquivos is None or rel.veredito == "bloqueado":
        raise ValueError("pacote recusado: %s" % "; ".join(a["mensagem"] for a in rel.achados[:3]))
    m = checar_manifesto(arquivos, rel)
    if m is None or rel.veredito == "bloqueado":
        raise ValueError("mod.json recusado")
    return arquivos, m, rel.sha256


if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    r = verificar(sys.argv[1])
    print(json.dumps(r, ensure_ascii=False, indent=2))
    sys.exit({"limpo": 0, "atencao": 1, "bloqueado": 2}[r["veredito"]])
