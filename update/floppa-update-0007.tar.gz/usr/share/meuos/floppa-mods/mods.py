# -*- coding: utf-8 -*-
"""Floppa Mods - o gerenciador (sem interface): catalogo, quarentena, ativar/desativar e a jaula.

Regras de seguranca (valem para TODO mod, oficial ou da comunidade):
  - nada roda como administrador: o Floppa Mods se recusa a rodar como root
  - so grava em pastas do usuario (temas, icones, fundos, fontes, dados do mod) e anota cada arquivo
  - desativar desfaz tudo (arquivos, configuracoes, atalhos, fundo, efeitos)
  - os programas dos mods rodam numa jaula (bubblewrap): sem a pasta pessoal de verdade, sem o sistema
    gravavel, sem internet (a nao ser que o Escudo tenha avisado que o mod usa) e sem o barramento D-Bus
  - mods da comunidade ficam 1 hora em quarentena: o Escudo confere ao chegar e de novo no fim da hora,
    com a lista negra atualizada
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
import urllib.request

import escudo

HOME = os.path.expanduser("~")
BASE = os.path.join(HOME, ".local", "share", "floppa-mods")
CACHE = os.path.join(HOME, ".cache", "floppa-mods")
CONF = "/etc/meuos/floppa-mods.conf"
REPO_ARQ = "/etc/meuos/repo-mods"
REPO_PADRAO = "https://raw.githubusercontent.com/Heitorcoser/FloppaOS/main/mods"
CHAVE_PUB = "/etc/meuos/floppa-update.pub"
AGENTE = "FloppaMods/1.0"

RAIZES = {   # destino do mod.json -> pasta real (dentro da pasta pessoal)
    "fundos": lambda i: os.path.join(HOME, ".local", "share", "backgrounds", "floppa-mods", i),
    "temas": lambda i: os.path.join(HOME, ".themes"),
    "icones": lambda i: os.path.join(HOME, ".icons"),
    "cursores": lambda i: os.path.join(HOME, ".icons"),
    "fontes": lambda i: os.path.join(HOME, ".local", "share", "fonts", "floppa-mods", i),
    "programas": lambda i: os.path.join(BASE, "dados", i, "programas"),
    "busca": lambda i: os.path.join(BASE, "dados", i, "busca"),
    "gtk-css": lambda i: os.path.join(HOME, ".config", "gtk-3.0", "floppa-mods", i),
    "sons": lambda i: os.path.join(HOME, ".local", "share", "sounds"),
}
GTK_CSS = os.path.join(HOME, ".config", "gtk-3.0", "gtk.css")
BUSCA_TEMA = os.path.join(HOME, ".config", "floppa", "busca.rasi")
APPS = os.path.join(HOME, ".local", "share", "applications")
AUTOSTART = os.path.join(HOME, ".config", "autostart")
MARCA_INI = "/* --- Floppa Mods: inicio (nao edite entre as marcas) --- */"
MARCA_FIM = "/* --- Floppa Mods: fim --- */"


class ErroMod(Exception):
    pass


# ======================================================================= utilidades
def agora():
    v = os.environ.get("FLOPPA_MODS_AGORA")
    return float(v) if v else time.time()


def quarentena_segundos():
    v = os.environ.get("FLOPPA_MODS_QUARENTENA_S")
    if v and v.isdigit():
        return int(v)
    try:
        with open(CONF, encoding="utf-8") as f:
            for linha in f:
                m = re.match(r"^\s*QUARENTENA_MIN\s*=\s*(\d+)\s*$", linha)
                if m:
                    return max(1, int(m.group(1))) * 60
    except OSError:
        pass
    return 3600


def conferir_usuario():
    if os.geteuid() == 0 and not os.environ.get("FLOPPA_MODS_TESTE_ROOT"):
        raise ErroMod("o Floppa Mods nao roda como administrador (root): abra como usuario normal.")


def pasta(*p):
    d = os.path.join(BASE, *p)
    os.makedirs(d, exist_ok=True)
    return d


def ler_json(caminho, padrao=None):
    try:
        with open(caminho, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return padrao


def gravar_json(caminho, dados):
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    tmp = caminho + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=1)
    os.replace(tmp, caminho)


def sha256_arquivo(caminho):
    h = hashlib.sha256()
    with open(caminho, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def dentro(raiz, caminho):
    raiz = os.path.realpath(raiz)
    c = os.path.realpath(caminho)
    return c == raiz or c.startswith(raiz + os.sep)


def gravar_arquivo(destino, dados, modo=0o644):
    """Grava sem seguir link no ultimo pedaco do caminho e de forma atomica."""
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    if os.path.islink(destino):
        raise ErroMod("o destino e um link (recusado): %s" % destino)
    tmp = destino + ".floppa-tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_NOFOLLOW", 0), modo)
    with os.fdopen(fd, "wb") as f:
        f.write(dados)
    os.replace(tmp, destino)


def rodar(cmd, timeout=15):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except (OSError, subprocess.TimeoutExpired) as e:
        return 1, str(e)


def avisar(titulo, texto):
    if shutil.which("notify-send"):
        rodar(["notify-send", "-i", "applications-other", titulo, texto], 5)


# ======================================================================= catalogo assinado (rede)
def repo():
    try:
        with open(REPO_ARQ, encoding="utf-8") as f:
            for linha in f:
                linha = linha.strip()
                if linha and not linha.startswith("#"):
                    return linha.rstrip("/")
    except OSError:
        pass
    return REPO_PADRAO


def baixar(nome, destino, limite):
    base = repo()
    if base.startswith(("http://", "https://")):
        req = urllib.request.Request(base + "/" + nome, headers={"User-Agent": AGENTE})
        origem = urllib.request.urlopen(req, timeout=30)
    else:
        origem = open(os.path.join(base[7:] if base.startswith("file://") else base, nome), "rb")
    tmp = destino + ".parte"
    total = 0
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    with origem as src, open(tmp, "wb") as out:
        while True:
            b = src.read(65536)
            if not b:
                break
            total += len(b)
            if total > limite:
                raise ErroMod("arquivo grande demais: %s" % nome)
            out.write(b)
    os.replace(tmp, destino)


def assinatura_ok(arquivo, sig):
    if os.environ.get("FLOPPA_MODS_CHAVE"):
        chave = os.environ["FLOPPA_MODS_CHAVE"]
    else:
        chave = CHAVE_PUB
    if not (os.path.isfile(chave) and shutil.which("openssl")):
        return False
    rc, _ = rodar(["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", chave, "-rawin",
                   "-in", arquivo, "-sigfile", sig], 20)
    return rc == 0


def ler_catalogo(texto):
    itens = []
    for linha in texto.splitlines():
        if not linha.strip() or linha.startswith("#"):
            continue
        c = linha.split("|")
        if len(c) < 10:
            continue
        ident, nome, tipo, versao, arq, sha, tam, origem, autor, desc = c[:10]
        if not (escudo.ID_MOD.match(ident) and re.match(r"^[0-9a-f]{64}$", sha) and
                re.match(r"^[A-Za-z0-9._-]+\.floppamod$", arq) and origem in ("oficial", "comunidade")):
            continue
        itens.append({"id": ident, "nome": nome, "tipo": tipo, "versao": versao, "arquivo": arq, "sha256": sha,
                      "tamanho": int(tam) if tam.isdigit() else 0, "origem": origem, "autor": autor,
                      "descricao": desc})
    return itens


def atualizar_catalogo():
    """Baixa catalogo.tsv e lista-negra.tsv (com assinatura). Devolve a lista de mods do catalogo."""
    os.makedirs(CACHE, exist_ok=True)
    for nome in ("catalogo.tsv", "lista-negra.tsv"):
        destino = os.path.join(CACHE, nome)
        novo, sig = destino + ".novo", destino + ".novo.sig"
        try:
            baixar(nome, novo, 2 * 1024 * 1024)
            baixar(nome + ".sig", sig, 4096)
        except Exception:
            continue
        if assinatura_ok(novo, sig):
            os.replace(novo, destino)
            os.replace(sig, destino + ".sig")
        else:
            for f in (novo, sig):
                if os.path.exists(f):
                    os.remove(f)
            if nome == "catalogo.tsv":
                raise ErroMod("o catalogo de mods veio sem assinatura valida (recusado por seguranca)")
    return catalogo()


LOCAL = os.environ.get("FLOPPA_MODS_LOCAL", "/usr/share/meuos/floppa-mods/repo")   # copia que vem na ISO


def _assinado(nome):
    """O arquivo assinado mais novo: o baixado (cache) ou, sem internet, o que veio na ISO."""
    for base in (CACHE, LOCAL):
        c = os.path.join(base, nome)
        if os.path.isfile(c) and assinatura_ok(c, c + ".sig"):
            with open(c, encoding="utf-8") as f:
                return f.read()
    return None


def catalogo():
    return ler_catalogo(_assinado("catalogo.tsv") or "")


def lista_negra():
    return escudo.ler_lista_negra(_assinado("lista-negra.tsv") or "")


# ======================================================================= estado dos mods
def _info(grupo, ident):
    return ler_json(os.path.join(BASE, grupo, ident, "info.json"))


def listar(grupo):
    d = os.path.join(BASE, grupo)
    out = []
    if os.path.isdir(d):
        for ident in sorted(os.listdir(d)):
            i = _info(grupo, ident)
            if i:
                out.append(i)
    return out


def estado(ident):
    for g in ("instalados", "quarentena", "recusados"):
        i = _info(g, ident)
        if i:
            return g, i
    return None, None


def donos_de_arquivos(exceto=None):
    donos = {}
    for i in listar("instalados"):
        if i["id"] != exceto:
            for a in i.get("arquivos", []):
                donos[a] = i["id"]
    return donos


# ======================================================================= instalar (checagem + quarentena)
def instalar_arquivo(caminho, origem_catalogo=None):
    """Confere um .floppamod e coloca na quarentena (comunidade) ou direto em instalados (oficial).
    Devolve (grupo, info)."""
    conferir_usuario()
    caminho = os.path.abspath(caminho)
    sha = sha256_arquivo(caminho) if os.path.isfile(caminho) else None
    oficial = None
    for item in catalogo():
        if item["sha256"] == sha and item["origem"] == "oficial":
            oficial = item
    rel = escudo.verificar(caminho, lista_negra=lista_negra())
    if rel["veredito"] == "bloqueado" or not rel["manifesto"]:
        raise ErroMod("o Floppa Escudo bloqueou este mod:\n" +
                      "\n".join("- %s %s" % (a["mensagem"], ("(%s)" % a["arquivo"]) if a["arquivo"] else "")
                                for a in rel["achados"] if a["nivel"] == "bloqueado")[:2000])
    ident = rel["manifesto"]["id"]
    if oficial and oficial["id"] != ident:
        oficial = None
    grupo_antigo, info_antiga = estado(ident)
    if grupo_antigo == "instalados" and info_antiga.get("ativo"):
        desativar(ident)
    for g in ("instalados", "quarentena", "recusados"):
        shutil.rmtree(os.path.join(BASE, g, ident), ignore_errors=True)

    grupo = "instalados" if oficial else "quarentena"
    d = pasta(grupo, ident)
    shutil.copyfile(caminho, os.path.join(d, "pacote.floppamod"))
    if sha256_arquivo(os.path.join(d, "pacote.floppamod")) != sha:
        raise ErroMod("o pacote mudou enquanto era copiado")
    info = dict(rel["manifesto"], sha256=sha, origem="oficial" if oficial else "comunidade",
                relatorio=rel, instalado_em=agora(), ativo=False, arquivos=[], desfazer={})
    if not oficial:
        info["quarentena_inicio"] = agora()
        info["quarentena_fim"] = agora() + quarentena_segundos()
    else:
        info["aprovado_em"] = agora()
    gravar_json(os.path.join(d, "info.json"), info)
    return grupo, info


def instalar_do_catalogo(ident):
    item = next((i for i in catalogo() if i["id"] == ident), None)
    if not item:
        raise ErroMod("mod '%s' nao esta no catalogo (atualize o catalogo)" % ident)
    destino = os.path.join(CACHE, "pacotes", item["arquivo"])
    local = os.path.join(LOCAL, "pacotes", item["arquivo"])
    if os.path.isfile(local) and sha256_arquivo(local) == item["sha256"]:   # veio na ISO: nem precisa baixar
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        shutil.copyfile(local, destino)
    else:
        baixar("pacotes/" + item["arquivo"], destino, escudo.LIMITE_PACOTE)
    if sha256_arquivo(destino) != item["sha256"]:
        os.remove(destino)
        raise ErroMod("o pacote baixado nao confere com o catalogo assinado (recusado)")
    try:
        return instalar_arquivo(destino)
    finally:
        if os.path.exists(destino):
            os.remove(destino)


def revisar_quarentena(forcar_rede=True):
    """Fim da quarentena: atualiza a lista negra, confere de novo e libera ou recusa.
    Devolve [(id, 'liberado'|'recusado'|'esperando', segundos_restantes)]."""
    conferir_usuario()
    if forcar_rede and any(agora() >= i["quarentena_fim"] for i in listar("quarentena")):
        try:
            atualizar_catalogo()
        except Exception:
            pass   # sem internet: usa a lista negra que ja tem
    negra = lista_negra()
    out = []
    for info in listar("quarentena"):
        ident = info["id"]
        falta = info["quarentena_fim"] - agora()
        if falta > 0:
            out.append((ident, "esperando", int(falta)))
            continue
        d = os.path.join(BASE, "quarentena", ident)
        pacote = os.path.join(d, "pacote.floppamod")
        rel = escudo.verificar(pacote, lista_negra=negra)
        if rel["veredito"] == "bloqueado" or not os.path.isfile(pacote) or sha256_arquivo(pacote) != info["sha256"]:
            info.update(relatorio=rel, recusado_em=agora())
            r = pasta("recusados", ident)
            gravar_json(os.path.join(r, "info.json"), info)
            shutil.rmtree(d, ignore_errors=True)
            out.append((ident, "recusado", 0))
            avisar("Floppa Mods", "O mod '%s' foi RECUSADO na checagem final e nao sera instalado." % info["nome"])
            continue
        info.update(relatorio=rel, aprovado_em=agora())
        destino = pasta("instalados", ident)
        shutil.move(pacote, os.path.join(destino, "pacote.floppamod"))
        gravar_json(os.path.join(destino, "info.json"), info)
        shutil.rmtree(d, ignore_errors=True)
        out.append((ident, "liberado", 0))
        avisar("Floppa Mods", "O mod '%s' passou na checagem de 1 hora. Ative no Floppa Mods." % info["nome"])
    return out


# ======================================================================= xfconf (com desfazer)
def xfconf_get(canal, prop):
    rc, out = rodar(["xfconf-query", "-c", canal, "-p", prop], 5)
    return out.strip() if rc == 0 else None


def xfconf_set(canal, prop, tipo, valor):
    v = ("true" if valor else "false") if tipo == "bool" else str(valor)
    rc, _ = rodar(["xfconf-query", "-c", canal, "-p", prop, "-s", v], 5)
    if rc != 0:
        rc, _ = rodar(["xfconf-query", "-c", canal, "-p", prop, "-n", "-t", tipo, "-s", v], 5)
    return rc == 0


def xfconf_reset(canal, prop):
    rodar(["xfconf-query", "-c", canal, "-p", prop, "-r"], 5)


def props_fundo():
    rc, out = rodar(["xfconf-query", "-c", "xfce4-desktop", "-l"], 5)
    return [p for p in out.split() if p.endswith("/last-image")] if rc == 0 else []


# ======================================================================= ativar / desativar
def _destino_real(ident, final):
    raiz_nome, _, resto = final.partition("/")
    raiz = RAIZES[raiz_nome](ident)
    real = os.path.normpath(os.path.join(raiz, resto))
    if real == os.path.normpath(raiz) or not dentro(raiz, real):
        raise ErroMod("destino fora do lugar permitido: %s" % final)
    return real


def comando_rodar(ident, prog):
    return "floppa-mods rodar %s %s" % (ident, prog)


def _desktop(ident, nome, prog, icone, terminal):
    return ("[Desktop Entry]\nType=Application\nName=%s\nComment=Mod do Floppa (%s)\nExec=%s\nIcon=%s\n"
            "Terminal=%s\nCategories=Game;FloppaMods;\nX-Floppa-Mod=%s\n"
            % (nome.replace("\n", " "), ident, comando_rodar(ident, prog), icone or "applications-games",
               "true" if terminal else "false", ident))


def atualizar_gtk_css():
    ativos = [i for i in listar("instalados") if i.get("ativo")]
    linhas = []
    for i in ativos:
        for a in i.get("arquivos", []):
            if a.endswith(".css") and dentro(os.path.join(HOME, ".config", "gtk-3.0", "floppa-mods"), a):
                linhas.append('@import url("%s");' % a.replace('"', ""))
    atual = ""
    if os.path.isfile(GTK_CSS):
        with open(GTK_CSS, encoding="utf-8", errors="replace") as f:
            atual = f.read()
    atual = re.sub(re.escape(MARCA_INI) + ".*?" + re.escape(MARCA_FIM) + "\n?", "", atual, flags=re.S)
    if linhas:
        atual = MARCA_INI + "\n" + "\n".join(linhas) + "\n" + MARCA_FIM + "\n" + atual
    if atual.strip() or os.path.isfile(GTK_CSS):
        gravar_arquivo(GTK_CSS, atual.encode("utf-8"))


def ativar(ident, aceitar_avisos=False):
    """Instala os arquivos e aplica as configuracoes de um mod ja aprovado. Desfaz tudo se algo falhar."""
    conferir_usuario()
    grupo, info = estado(ident)
    if grupo == "quarentena":
        falta = int(info["quarentena_fim"] - agora())
        raise ErroMod("o mod ainda esta em quarentena (faltam %d min)" % max(1, falta // 60 + 1))
    if grupo != "instalados":
        raise ErroMod("mod '%s' nao esta instalado" % ident)
    if info.get("ativo"):
        return info
    if info["relatorio"]["veredito"] == "atencao" and not aceitar_avisos:
        raise ErroMod("este mod tem avisos do Floppa Escudo: leia e confirme antes de ativar")
    d = os.path.join(BASE, "instalados", ident)
    pacote = os.path.join(d, "pacote.floppamod")
    if sha256_arquivo(pacote) != info["sha256"]:
        raise ErroMod("o pacote do mod foi alterado depois da checagem (recusado)")
    arquivos, m, _sha = escudo.ler_pacote(pacote)
    destinos = m["_destinos"]
    donos = donos_de_arquivos(exceto=ident)
    escritos, desfazer = [], {"xfconf": [], "fundo": [], "visual": None, "dock": False, "atalhos": []}
    info.update(arquivos=escritos, desfazer=desfazer)
    try:
        # 1) arquivos
        for final, de in sorted(destinos.items()):
            real = _destino_real(ident, final)
            if real in donos:
                raise ErroMod("o arquivo %s ja pertence ao mod '%s'" % (real, donos[real]))
            if os.path.exists(real) and real not in donos:
                raise ErroMod("ja existe um arquivo seu em %s (o mod nao apaga nada seu)" % real)
            gravar_arquivo(real, arquivos[de])
            escritos.append(real)
        # 2) configuracoes da lista branca
        for c in m.get("configuracoes", []):
            antes = xfconf_get(c["canal"], c["prop"])
            if xfconf_set(c["canal"], c["prop"], c.get("tipo") or escudo.LISTA_BRANCA[c["canal"]][c["prop"]][0],
                          c["valor"]):
                desfazer["xfconf"].append([c["canal"], c["prop"], escudo.LISTA_BRANCA[c["canal"]][c["prop"]][0],
                                           antes, str(c["valor"]).lower() if isinstance(c["valor"], bool) else str(c["valor"])])
        # 3) fundo de tela
        if m.get("fundo"):
            img = _destino_real(ident, escudo.normalizar(m["fundo"]))
            for p in props_fundo() or ["/backdrop/screen0/monitor0/workspace0/last-image"]:
                desfazer["fundo"].append([p, xfconf_get("xfce4-desktop", p)])
                xfconf_set("xfce4-desktop", p, "string", img)
        # 4) efeitos visuais
        if m.get("visual") and shutil.which("floppa-visual"):
            _rc, est = rodar(["floppa-visual", "estado"], 10)
            desfazer["visual"] = (est.split() or ["auto"])[0]
            rodar(["floppa-visual", m["visual"]], 20)
        # 5) dock
        if m.get("dock"):
            dock = os.path.join(AUTOSTART, "floppa-dock.desktop")
            if not os.path.exists(dock):
                gravar_arquivo(dock, b"[Desktop Entry]\nType=Application\nName=Dock do Floppa\nExec=plank\n"
                                     b"OnlyShowIn=XFCE;\nHidden=false\n")
                escritos.append(dock)
                desfazer["dock"] = True
                if shutil.which("plank"):
                    subprocess.Popen(["plank"], start_new_session=True, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
        # 6) aplicativos no menu
        for n, a in enumerate(m.get("aplicativos", [])):
            prog = escudo.normalizar(a["executar"]).split("/", 1)[1]
            icone = _destino_real(ident, escudo.normalizar(a["icone"])) if a.get("icone") else None
            arq = os.path.join(APPS, "floppa-mod-%s-%d.desktop" % (ident, n))
            gravar_arquivo(arq, _desktop(ident, a["nome"], prog, icone, a.get("terminal", False)).encode())
            escritos.append(arq)
        # 7) atalhos de teclado (nunca por cima de um que ja existe)
        for a in m.get("atalhos", []):
            prop = "/commands/custom/" + a["tecla"]
            if xfconf_get("xfce4-keyboard-shortcuts", prop):
                raise ErroMod("a tecla %s ja tem outro atalho" % a["tecla"])
            prog = escudo.normalizar(a["executar"]).split("/", 1)[1]
            cmd_atalho = comando_rodar(ident, prog)
            if a.get("terminal", not prog.endswith(".py")):   # jogos/programas de texto abrem num terminal
                cmd_atalho = "xfce4-terminal --title=%s -x %s" % (ident, cmd_atalho)
            if xfconf_set("xfce4-keyboard-shortcuts", prop, "string", cmd_atalho):
                desfazer["atalhos"].append(prop)
        # 8) abrir ao entrar
        if m.get("iniciar_ao_entrar"):
            prog = escudo.normalizar(m["iniciar_ao_entrar"]).split("/", 1)[1]
            arq = os.path.join(AUTOSTART, "floppa-mod-%s.desktop" % ident)
            gravar_arquivo(arq, _desktop(ident, info["nome"], prog, None, False).encode())
            escritos.append(arq)
        # 9) tema da busca e fontes
        for real in escritos:
            if real.endswith(".rasi") and dentro(RAIZES["busca"](ident), real):
                if os.path.exists(BUSCA_TEMA) and BUSCA_TEMA not in donos:
                    desfazer["busca_antes"] = open(BUSCA_TEMA, "rb").read().decode("utf-8", "replace")
                with open(real, "rb") as f:
                    gravar_arquivo(BUSCA_TEMA, f.read())
                escritos.append(BUSCA_TEMA)
                break
        info["ativo"] = True
        gravar_json(os.path.join(d, "info.json"), info)
        atualizar_gtk_css()
        if any(dentro(RAIZES["fontes"](ident), r) for r in escritos) and shutil.which("fc-cache"):
            rodar(["fc-cache", "-f", RAIZES["fontes"](ident)], 60)
        return info
    except Exception:
        info["ativo"] = True   # para o desfazer saber o que limpar
        _desfazer(ident, info)
        info.update(ativo=False, arquivos=[], desfazer={})
        gravar_json(os.path.join(d, "info.json"), info)
        raise


def _desfazer(ident, info):
    desf = info.get("desfazer") or {}
    for canal, prop, tipo, antes, posto in reversed(desf.get("xfconf", [])):
        if xfconf_get(canal, prop) == posto:          # so desfaz se o usuario nao mudou depois
            if antes is None:
                xfconf_reset(canal, prop)
            else:
                xfconf_set(canal, prop, tipo, antes if tipo != "bool" else antes == "true")
    for prop, antes in desf.get("fundo", []):
        if antes is not None:
            xfconf_set("xfce4-desktop", prop, "string", antes)
    if desf.get("visual") and shutil.which("floppa-visual"):
        rodar(["floppa-visual", desf["visual"]], 20)
    for prop in desf.get("atalhos", []):
        xfconf_reset("xfce4-keyboard-shortcuts", prop)
    if desf.get("dock"):
        rodar(["pkill", "-u", str(os.getuid()), "-x", "plank"], 5)
    for real in reversed(info.get("arquivos", [])):
        try:
            if os.path.isfile(real) and not os.path.islink(real):
                os.remove(real)
        except OSError:
            pass
        # apaga pastas que ficaram vazias (so as que o mod criou dentro das raizes)
        p = os.path.dirname(real)
        while p.startswith(HOME + os.sep) and p not in (HOME, os.path.join(HOME, ".themes"),
                                                        os.path.join(HOME, ".icons"), APPS, AUTOSTART):
            try:
                os.rmdir(p)
            except OSError:
                break
            p = os.path.dirname(p)
    if "busca_antes" in desf:
        gravar_arquivo(BUSCA_TEMA, desf["busca_antes"].encode("utf-8"))


def desativar(ident):
    conferir_usuario()
    grupo, info = estado(ident)
    if grupo != "instalados" or not info.get("ativo"):
        return info
    _desfazer(ident, info)
    info.update(ativo=False, arquivos=[], desfazer={})
    gravar_json(os.path.join(BASE, "instalados", ident, "info.json"), info)
    atualizar_gtk_css()
    shutil.rmtree(os.path.join(BASE, "dados", ident, "programas"), ignore_errors=True)
    shutil.rmtree(os.path.join(BASE, "dados", ident, "busca"), ignore_errors=True)
    return info


def remover(ident, apagar_dados=True):
    conferir_usuario()
    grupo, _info_ = estado(ident)
    if grupo is None:
        raise ErroMod("mod '%s' nao encontrado" % ident)
    if grupo == "instalados":
        desativar(ident)
    for g in ("instalados", "quarentena", "recusados"):
        shutil.rmtree(os.path.join(BASE, g, ident), ignore_errors=True)
    if apagar_dados:
        shutil.rmtree(os.path.join(BASE, "dados", ident), ignore_errors=True)
        shutil.rmtree(os.path.join(BASE, "casa", ident), ignore_errors=True)


# ======================================================================= a jaula (bubblewrap)
def comando_jaula(ident, prog, internet=False, tela=False):
    """Monta o comando do bubblewrap para rodar um programa do mod. Levanta ErroMod se nao der."""
    grupo, info = estado(ident)
    if grupo != "instalados" or not info.get("ativo"):
        raise ErroMod("o mod '%s' nao esta ativo" % ident)
    progs = os.path.join(BASE, "dados", ident, "programas")
    alvo = os.path.normpath(os.path.join(progs, prog))
    if not dentro(progs, alvo) or not os.path.isfile(alvo) or alvo not in info.get("arquivos", []):
        raise ErroMod("programa invalido: %s" % prog)
    ext = os.path.splitext(alvo)[1].lower()
    interp = {".flp": "/usr/local/bin/floopyc", ".sh": "/bin/bash", ".py": "/usr/bin/python3"}.get(ext)
    if not interp:
        raise ErroMod("o Floppa Mods so roda .flp, .sh e .py")
    bwrap = shutil.which("bwrap")
    if not bwrap:
        raise ErroMod("a jaula dos mods (bubblewrap) nao esta instalada: por seguranca o programa nao abre.\n"
                      "Instale com:  sudo apt install bubblewrap   (temas, fundos e painel funcionam sem ela)")
    casa = pasta("casa", ident)                   # a "pasta pessoal" que o mod enxerga
    falsa = "/home/floppa-mod"
    cmd = [bwrap, "--unshare-all", "--die-with-parent", "--new-session",
           "--ro-bind", "/usr", "/usr", "--ro-bind", "/etc", "/etc",
           "--symlink", "usr/bin", "/bin", "--symlink", "usr/sbin", "/sbin",
           "--symlink", "usr/lib", "/lib", "--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp",
           "--tmpfs", "/home", "--bind", casa, falsa, "--ro-bind", progs, falsa + "/mod",
           "--setenv", "HOME", falsa, "--setenv", "USER", "floppa-mod", "--setenv", "FLOPPA_MOD", ident,
           "--unsetenv", "DBUS_SESSION_BUS_ADDRESS", "--unsetenv", "SSH_AUTH_SOCK", "--unsetenv", "XAUTHORITY",
           "--chdir", falsa + "/mod", "--hostname", "floppa-mod"]
    if os.path.isdir("/usr/lib64"):
        cmd += ["--symlink", "usr/lib64", "/lib64"]
    if internet:
        cmd += ["--share-net"]
    run = os.environ.get("XDG_RUNTIME_DIR")
    if run:   # som (sem o resto do runtime: nada de D-Bus, chaveiro, etc.)
        for s in ("pulse", "pipewire-0"):
            if os.path.exists(os.path.join(run, s)):
                cmd += ["--bind", os.path.join(run, s), "/run/user/floppa/" + s]
        cmd += ["--setenv", "XDG_RUNTIME_DIR", "/run/user/floppa",
                "--setenv", "PULSE_SERVER", "unix:/run/user/floppa/pulse/native"]
    if tela and os.environ.get("DISPLAY") and os.path.isdir("/tmp/.X11-unix"):
        cmd += ["--ro-bind", "/tmp/.X11-unix", "/tmp/.X11-unix"]
        xa = os.environ.get("XAUTHORITY") or os.path.join(HOME, ".Xauthority")
        if os.path.isfile(xa):
            cmd += ["--ro-bind", xa, falsa + "/.Xauthority", "--setenv", "XAUTHORITY", falsa + "/.Xauthority"]
    cmd += ["--", interp, falsa + "/mod/" + os.path.relpath(alvo, progs)]
    return cmd


def rodar_programa(ident, prog):
    conferir_usuario()
    grupo, info = estado(ident)
    if grupo != "instalados":
        raise ErroMod("o mod '%s' nao esta instalado" % ident)
    achados = info.get("relatorio", {}).get("achados", [])
    internet = any(a["codigo"] == "internet" for a in achados)
    m = None
    try:
        _arq, m, _s = escudo.ler_pacote(os.path.join(BASE, "instalados", ident, "pacote.floppamod"))
    except Exception:
        pass
    tela = False
    for a in (m or {}).get("aplicativos", []):
        if escudo.normalizar(a.get("executar", "")) == "programas/" + prog and not a.get("terminal", False):
            tela = True
    cmd = comando_jaula(ident, prog, internet=internet, tela=tela)
    return subprocess.call(cmd)
